// SettingsView — redesigned for the UI kit.
// Two-pane layout: section nav (left) + grouped settings rows (right).
// Consolidates LLM + Entity into one "Models" section, hides developer notes under "About".

const SECTIONS = [
  { id: "account",   icon: "user-round",  title: "Account",     subtitle: "계정" },
  { id: "workspace", icon: "globe-2",     title: "Workspace",   subtitle: "워크스페이스" },
  { id: "models",    icon: "brain-circuit", title: "Models",    subtitle: "모델" },
  { id: "desktop",   icon: "laptop-minimal", title: "Desktop",  subtitle: "데스크톱" },
  { id: "about",     icon: "info",        title: "About",       subtitle: "정보" },
];

const MOCK_MODELS = [
  { name: "gpt-oss:120b",          size: 65.0, role: "chat" },
  { name: "gpt-oss:20b",           size: 12.4, role: "chat" },
  { name: "qwen2.5:14b-instruct",  size:  9.0, role: "chat" },
  { name: "llama3.1:8b",           size:  4.7, role: "chat" },
  { name: "granite3-guardian:8b",  size:  4.9, role: "guardian" },
];

const SettingsView = () => {
  const [section, setSection]       = React.useState("account");
  const [locale, setLocale]         = React.useState("ko");
  const [llmModel, setLlmModel]     = React.useState("gpt-oss:120b");
  const [entityModel, setEntityModel] = React.useState("inherit");
  const [feedback, setFeedback]     = React.useState(null);

  const flash = (msg) => {
    setFeedback(msg);
    setTimeout(() => setFeedback(null), 2500);
  };

  return (
    <div style={{
      height: "100%", display: "flex",
      background: "var(--color-bg-surface)", overflow: "hidden",
    }}>
      {/* Section rail */}
      <aside style={{
        width: 224, flexShrink: 0,
        background: "var(--color-bg-panel)",
        borderRight: "1px solid var(--color-border-subtle)",
        padding: "18px 12px",
        display: "flex", flexDirection: "column", gap: 4,
      }}>
        <div className="eyebrow" style={{ padding: "0 10px 10px" }}>Settings · 설정</div>
        {SECTIONS.map((s) => {
          const active = section === s.id;
          return (
            <button
              key={s.id}
              onClick={() => setSection(s.id)}
              style={{
                display: "flex", alignItems: "center", gap: 10,
                padding: "8px 10px", width: "100%",
                borderRadius: "var(--radius-sm)", border: "none",
                cursor: "pointer", textAlign: "left",
                background: active ? "var(--color-accent-subtle)" : "transparent",
                color: active ? "var(--color-accent)" : "var(--color-text-secondary)",
                fontSize: 13,
                fontWeight: active ? 600 : 400,
                transition: "background var(--transition-fast), color var(--transition-fast)",
              }}
            >
              <Icon name={s.icon} size={15} color={active ? "var(--color-accent)" : "var(--color-text-muted)"} />
              <div style={{ display: "grid", lineHeight: 1.2 }}>
                <span>{s.title}</span>
                <span style={{ fontSize: 10.5, color: active ? "var(--color-accent)" : "var(--color-text-muted)", opacity: 0.85 }}>
                  {s.subtitle}
                </span>
              </div>
            </button>
          );
        })}
      </aside>

      {/* Content */}
      <div className="scroll-y" style={{ flex: 1 }}>
        <div style={{ maxWidth: 720, margin: "0 auto", padding: "28px 32px 60px" }}>
          {section === "account"   ? <AccountSection   onFeedback={flash} /> : null}
          {section === "workspace" ? <WorkspaceSection locale={locale} setLocale={(l) => { setLocale(l); flash(l === "ko" ? "표시 언어를 한국어로 변경했습니다." : "Display language changed to English."); }} /> : null}
          {section === "models"    ? <ModelsSection
            llmModel={llmModel} setLlmModel={(m) => { setLlmModel(m); flash(`LLM 모델: ${m}`); }}
            entityModel={entityModel} setEntityModel={(m) => { setEntityModel(m); flash(`엔티티 모델: ${m === "inherit" ? "채팅 모델 사용" : m}`); }}
            onFeedback={flash}
          /> : null}
          {section === "desktop"   ? <DesktopSection   onFeedback={flash} /> : null}
          {section === "about"     ? <AboutSection /> : null}

          {feedback ? <Toast text={feedback} /> : null}
        </div>
      </div>
    </div>
  );
};

/* ──────────────────────────────────────────────
   Reusable section primitives
   ────────────────────────────────────────────── */

const SectionHeader = ({ title, subtitle }) => (
  <header style={{ marginBottom: 22 }}>
    <h1 style={{ fontSize: 24, fontWeight: 700, letterSpacing: "-0.02em", lineHeight: 1.2 }}>{title}</h1>
    {subtitle ? (
      <p style={{ fontSize: 13, color: "var(--color-text-secondary)", marginTop: 6, lineHeight: 1.65, maxWidth: 600 }}>
        {subtitle}
      </p>
    ) : null}
  </header>
);

const Row = ({ label, description, control, danger }) => (
  <div style={{
    display: "grid",
    gridTemplateColumns: "1fr auto",
    columnGap: 24,
    alignItems: "center",
    padding: "16px 0",
    borderBottom: "1px solid var(--color-border-subtle)",
  }}>
    <div style={{ display: "grid", gap: 4, minWidth: 0 }}>
      <span style={{
        fontSize: 13, fontWeight: 600,
        color: danger ? "var(--color-danger)" : "var(--color-text-primary)",
      }}>{label}</span>
      {description ? (
        <span style={{ fontSize: 12, color: "var(--color-text-muted)", lineHeight: 1.6 }}>{description}</span>
      ) : null}
    </div>
    <div style={{ flexShrink: 0 }}>{control}</div>
  </div>
);

const RowGroup = ({ title, children }) => (
  <section style={{ marginBottom: 28 }}>
    {title ? (
      <div className="eyebrow" style={{ marginBottom: 6 }}>{title}</div>
    ) : null}
    <div>{children}</div>
  </section>
);

const Select = ({ value, onChange, options, disabled, width = 260 }) => (
  <select
    value={value}
    onChange={(e) => onChange(e.target.value)}
    disabled={disabled}
    style={{
      width, height: 32,
      borderRadius: "var(--radius-sm)",
      border: "1px solid var(--color-border-subtle)",
      background: "var(--color-bg-elevated)",
      padding: "0 12px",
      fontSize: 12.5,
      color: "var(--color-text-primary)",
      outline: "none",
      cursor: disabled ? "not-allowed" : "pointer",
      fontFamily: "var(--font-sans)",
    }}
  >
    {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
  </select>
);

const SegmentedControl = ({ value, onChange, options }) => (
  <div style={{
    display: "inline-flex",
    background: "var(--color-bg-panel)",
    border: "1px solid var(--color-border-subtle)",
    borderRadius: "var(--radius-sm)",
    padding: 2, gap: 2,
  }}>
    {options.map((o) => {
      const active = value === o.value;
      return (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          style={{
            padding: "5px 12px",
            border: "none",
            borderRadius: "var(--radius-xs)",
            background: active ? "var(--color-bg-elevated)" : "transparent",
            color: active ? "var(--color-accent)" : "var(--color-text-muted)",
            fontSize: 12, fontWeight: active ? 600 : 500,
            cursor: "pointer",
            boxShadow: active ? "0 1px 3px rgba(15,23,42,0.08)" : "none",
            whiteSpace: "nowrap",
          }}
        >{o.label}</button>
      );
    })}
  </div>
);

const Button = ({ children, onClick, variant = "secondary", disabled, icon }) => {
  const baseStyle = {
    display: "inline-flex", alignItems: "center", gap: 6,
    height: 32, padding: "0 14px",
    borderRadius: "var(--radius-sm)",
    fontSize: 12, fontWeight: 500,
    cursor: disabled ? "not-allowed" : "pointer",
    transition: "background var(--transition-fast)",
  };
  if (variant === "primary") {
    Object.assign(baseStyle, {
      background: "var(--color-accent)", color: "#fff", border: "none",
    });
  } else if (variant === "danger") {
    Object.assign(baseStyle, {
      background: "transparent", color: "var(--color-danger)",
      border: "1px solid rgba(220, 38, 38, 0.3)",
    });
  } else {
    Object.assign(baseStyle, {
      background: "var(--color-bg-elevated)",
      color: "var(--color-text-secondary)",
      border: "1px solid var(--color-border-subtle)",
    });
  }
  if (disabled) baseStyle.opacity = 0.5;
  return (
    <button onClick={onClick} disabled={disabled} style={baseStyle}>
      {icon ? <Icon name={icon} size={13} /> : null}
      {children}
    </button>
  );
};

const Toast = ({ text }) => (
  <div style={{
    position: "fixed", bottom: 24, left: "50%", transform: "translateX(-50%)",
    background: "var(--color-text-primary)", color: "#fff",
    padding: "10px 16px",
    borderRadius: "var(--radius-md)",
    fontSize: 12.5, fontWeight: 500,
    boxShadow: "var(--shadow-md)",
    zIndex: 100,
  }}>{text}</div>
);

/* ──────────────────────────────────────────────
   Sections
   ────────────────────────────────────────────── */

const AccountSection = ({ onFeedback }) => (
  <>
    <SectionHeader
      title="Account"
      subtitle="이 워크스페이스에 로그인된 계정과 인증 상태."
    />

    {/* Identity strip */}
    <div style={{
      display: "flex", alignItems: "center", gap: 16,
      padding: "16px 18px",
      background: "var(--color-bg-elevated)",
      border: "1px solid var(--color-border-subtle)",
      borderRadius: "var(--radius-md)",
      marginBottom: 24,
    }}>
      <div style={{
        width: 56, height: 56,
        borderRadius: "50%",
        background: "linear-gradient(135deg, #2563eb 0%, #0f766e 100%)",
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "#fff", fontSize: 22, fontWeight: 700,
        flexShrink: 0,
      }}>김</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 16, fontWeight: 600, color: "var(--color-text-primary)" }}>김연구</div>
        <div style={{ fontSize: 12.5, color: "var(--color-text-muted)", marginTop: 2 }}>
          researcher@lab.org · Lab workspace · Researcher
        </div>
      </div>
      <Button icon="log-out" variant="secondary" onClick={() => onFeedback("로그아웃되었습니다.")}>
        Sign out
      </Button>
    </div>

    <RowGroup title="Security · 보안">
      <Row
        label="Password"
        description="마지막 변경 12일 전. 8자 이상 권장."
        control={<Button icon="key-round" onClick={() => onFeedback("비밀번호 변경 화면은 데스크톱 셸에서 열립니다.")}>Change</Button>}
      />
      <Row
        label="Active sessions"
        description="현재 1대 (이 기기 · Electron)."
        control={<Button icon="monitor" onClick={() => onFeedback("세션 목록을 확인했습니다.")}>Manage</Button>}
      />
    </RowGroup>

    <RowGroup title="Danger zone · 위험 영역">
      <Row
        label="Delete account"
        description="모든 논문, 노트, 하이라이트, 채팅 기록이 영구 삭제됩니다."
        control={<Button icon="trash-2" variant="danger">Delete</Button>}
        danger
      />
    </RowGroup>
  </>
);

const WorkspaceSection = ({ locale, setLocale }) => (
  <>
    <SectionHeader
      title="Workspace"
      subtitle="셸 표시 언어와 워크스페이스 전반 동작."
    />

    <RowGroup title="Appearance · 표시">
      <Row
        label="Display language"
        description="셸 언어를 영어/한국어 사이에서 전환. 일부 깊은 화면은 영어로 유지될 수 있음."
        control={
          <SegmentedControl
            value={locale}
            onChange={setLocale}
            options={[{ value: "en", label: "English" }, { value: "ko", label: "한국어" }]}
          />
        }
      />
      <Row
        label="Theme"
        description="Redou는 현재 라이트 테마 전용입니다."
        control={
          <SegmentedControl
            value="light"
            onChange={() => {}}
            options={[{ value: "light", label: "Light" }, { value: "dark", label: "Dark · 준비 중" }]}
          />
        }
      />
    </RowGroup>

    <RowGroup title="Library · 라이브러리">
      <Row
        label="Default view"
        description="새 세션 시작 시 라이브러리를 어떻게 보여줄지."
        control={
          <SegmentedControl
            value="grid"
            onChange={() => {}}
            options={[{ value: "grid", label: "Grid" }, { value: "list", label: "List" }]}
          />
        }
      />
      <Row
        label="Default sort"
        control={
          <Select
            value="addedAt"
            onChange={() => {}}
            options={[
              { value: "addedAt", label: "Date added · 추가일" },
              { value: "year", label: "Year · 연도" },
              { value: "title", label: "Title · 제목" },
              { value: "citations", label: "Citations · 인용 수" },
            ]}
            width={220}
          />
        }
      />
    </RowGroup>
  </>
);

const ModelsSection = ({ llmModel, setLlmModel, entityModel, setEntityModel, onFeedback }) => {
  const chatModels = MOCK_MODELS.filter((m) => m.role === "chat");
  const modelOptions = chatModels.map((m) => ({
    value: m.name,
    label: `${m.name}   (${m.size.toFixed(1)} GB)`,
  }));

  return (
    <>
      <SectionHeader
        title="Models"
        subtitle="채팅·테이블 생성·엔티티 추출에 사용하는 Ollama 모델. Guardian과 OCR 모델은 별도 채널을 씁니다."
      />

      {/* Status strip */}
      <div style={{
        display: "flex", alignItems: "center", gap: 12,
        padding: "10px 14px",
        background: "rgba(15, 118, 110, 0.08)",
        border: "1px solid rgba(15, 118, 110, 0.22)",
        borderRadius: "var(--radius-sm)",
        marginBottom: 22,
        fontSize: 12.5,
      }}>
        <Icon name="check-circle-2" size={14} color="var(--color-success)" />
        <span style={{ color: "var(--color-success)", fontWeight: 600 }}>Ollama 연결됨</span>
        <span style={{ color: "var(--color-text-muted)" }}>localhost:11434 · {chatModels.length} models available</span>
        <div style={{ flex: 1 }} />
        <button
          onClick={() => onFeedback("모델 목록을 새로고침했습니다.")}
          style={{
            background: "transparent", border: "none", cursor: "pointer",
            color: "var(--color-text-muted)", display: "flex", alignItems: "center", gap: 4,
            fontSize: 11.5, fontWeight: 500,
          }}
        >
          <Icon name="refresh-cw" size={12} />Refresh
        </button>
      </div>

      <RowGroup title="Chat & table generation · 채팅·테이블 생성">
        <Row
          label="Active model"
          description={`Granite Guardian이 별도 모델로 셀별 사실 검증을 수행합니다.`}
          control={<Select value={llmModel} onChange={setLlmModel} options={modelOptions} />}
        />
        <Row
          label="Streaming"
          description="응답을 토큰 단위로 스트리밍 (비활성화 시 한 번에 전체 응답)."
          control={
            <SegmentedControl
              value="on"
              onChange={() => {}}
              options={[{ value: "on", label: "On" }, { value: "off", label: "Off" }]}
            />
          }
        />
        <Row
          label="Guardian verification"
          description="Granite Guardian 3.3 8B가 각 셀을 근거와 대조해 검증."
          control={
            <SegmentedControl
              value="strict"
              onChange={() => {}}
              options={[
                { value: "off",     label: "Off" },
                { value: "warn",    label: "Warn" },
                { value: "strict",  label: "Strict" },
              ]}
            />
          }
        />
      </RowGroup>

      <RowGroup title="Knowledge graph · 지식 그래프">
        <Row
          label="Entity extraction model"
          description="물질·방법·조건·지표 등 엔티티와 관계 추출."
          control={
            <Select
              value={entityModel}
              onChange={setEntityModel}
              options={[
                { value: "inherit", label: "Inherits chat model · 채팅 모델 사용" },
                ...modelOptions,
              ]}
            />
          }
        />

        {/* Backfill progress */}
        <Row
          label="Backfill all papers"
          description="진행 12 / 18 (버전 4) · 대기 6, 실행 중 1"
          control={
            <Button icon="refresh-cw" onClick={() => onFeedback("엔티티 추출을 시작했습니다.")}>
              Re-extract
            </Button>
          }
        />
        <div style={{ paddingBottom: 16 }}>
          <div style={{
            height: 4, background: "var(--color-bg-panel)",
            borderRadius: 99, overflow: "hidden", marginTop: -8,
          }}>
            <div style={{
              width: "67%", height: "100%",
              background: "var(--color-accent)",
            }} />
          </div>
        </div>
      </RowGroup>
    </>
  );
};

const DesktopSection = ({ onFeedback }) => (
  <>
    <SectionHeader
      title="Desktop"
      subtitle="Electron 셸이 연결됐을 때만 동작하는 파일 시스템·백업 기능."
    />

    {/* Runtime card — compact summary */}
    <div style={{
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: 0,
      background: "var(--color-bg-elevated)",
      border: "1px solid var(--color-border-subtle)",
      borderRadius: "var(--radius-md)",
      marginBottom: 24,
      overflow: "hidden",
    }}>
      {[
        { label: "Runtime",  value: "Electron 35.1.4" },
        { label: "Platform", value: "darwin · arm64" },
        { label: "Library",  value: "~/Library/Application Support/Redou" },
        { label: "Status",   value: "Connected", success: true },
      ].map((kv, i) => (
        <div key={kv.label} style={{
          padding: "14px 16px",
          borderRight: i % 2 === 0 ? "1px solid var(--color-border-subtle)" : "none",
          borderBottom: i < 2 ? "1px solid var(--color-border-subtle)" : "none",
        }}>
          <div className="eyebrow" style={{ marginBottom: 4 }}>{kv.label}</div>
          <div style={{
            fontSize: 12.5, fontWeight: 600,
            color: kv.success ? "var(--color-success)" : "var(--color-text-primary)",
            wordBreak: "break-all",
          }}>
            {kv.success ? <Icon name="check-circle-2" size={12} color="var(--color-success)" style={{ marginRight: 5 }} /> : null}
            {kv.value}
          </div>
        </div>
      ))}
    </div>

    <RowGroup title="File actions · 파일 작업">
      <Row
        label="Select PDFs"
        description="데스크톱 대화상자에서 PDF 여러 개를 선택해 임포트."
        control={<Button icon="folder-open" onClick={() => onFeedback("PDF 대화상자가 열렸습니다.")}>Select</Button>}
      />
      <Row
        label="Reveal library"
        description="라이브러리 폴더를 탐색기에서 열기."
        control={<Button icon="external-link" onClick={() => onFeedback("탐색기에서 라이브러리를 열었습니다.")}>Reveal</Button>}
      />
    </RowGroup>

    <RowGroup title="Backup · 백업">
      <Row
        label="Create workspace backup"
        description="모든 논문·노트·하이라이트·임베딩을 .zip으로 묶어 저장."
        control={<Button icon="hard-drive-download" variant="primary" onClick={() => onFeedback("백업을 생성했습니다.")}>Backup now</Button>}
      />
      <Row
        label="Latest backup"
        description="2025-05-26 14:22 · 1.24 GB · ~/Backups/redou-20250526.zip"
        control={<Button icon="external-link" onClick={() => onFeedback("최근 백업을 탐색기에서 열었습니다.")}>Reveal</Button>}
      />
    </RowGroup>

    <RowGroup title="Pipeline · 파이프라인">
      <Row
        label="Re-extract all papers"
        description="추출 버전이 올라갔을 때 라이브러리 전체를 다시 처리."
        control={<Button icon="refresh-cw" onClick={() => onFeedback("전체 재추출을 시작했습니다.")}>Re-extract</Button>}
      />
    </RowGroup>
  </>
);

const AboutSection = () => (
  <>
    <SectionHeader title="About" subtitle="버전·라이선스·개발 노트." />

    <RowGroup title="Build">
      <Row label="Version"     control={<code style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--color-text-muted)" }}>0.1.0 · main@3799fd2</code>} />
      <Row label="Electron"    control={<code style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--color-text-muted)" }}>35.1.4</code>} />
      <Row label="React"       control={<code style={{ fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--color-text-muted)" }}>19.0.0</code>} />
      <Row label="Frontend stack" description="Vite 6 · TailwindCSS v4 · TanStack Query · Zustand" control={<span />} />
    </RowGroup>

    <RowGroup title="Services">
      <Row label="Supabase"   description="PostgreSQL + pgvector · http://127.0.0.1:55321" control={<StatusPill status="up" /> } />
      <Row label="Ollama"     description="LLM, OCR · http://localhost:11434" control={<StatusPill status="up" />} />
      <Row label="MineRU"     description="Structured PDF parsing · :8001" control={<StatusPill status="up" />} />
      <Row label="UniMERNet"  description="Equation → LaTeX · :8010" control={<StatusPill status="warn" />} />
      <Row label="GROBID"     description="Metadata + references · :8070" control={<StatusPill status="up" />} />
    </RowGroup>

    <RowGroup title="Diagnostics · 진단">
      <Row label="Export diagnostic bundle" description="이슈 리포트를 위해 로그·세션 정보를 .zip으로 묶음." control={<Button icon="bug">Export</Button>} />
      <Row label="Open log folder" control={<Button icon="external-link">Open</Button>} />
    </RowGroup>
  </>
);

const StatusPill = ({ status }) => {
  const cfg = {
    up:   { color: "var(--color-success)", bg: "rgba(15, 118, 110, 0.12)",  label: "Up" },
    warn: { color: "var(--color-warning)", bg: "rgba(217, 119, 6, 0.12)",   label: "Slow" },
    down: { color: "var(--color-danger)",  bg: "rgba(220, 38, 38, 0.12)",   label: "Down" },
  }[status];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "3px 8px", borderRadius: "var(--radius-xs)",
      background: cfg.bg, color: cfg.color,
      fontSize: 10.5, fontWeight: 700, letterSpacing: "0.03em",
    }}>
      <span style={{ width: 6, height: 6, borderRadius: "50%", background: cfg.color }} />
      {cfg.label}
    </span>
  );
};

window.SettingsView = SettingsView;
