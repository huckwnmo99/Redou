// LeftSidebar — fixed 224px nav with workspace tabs + folder tree.
const NAV_ITEMS = [
  { id: "library",    label: "라이브러리",  en: "Library",    icon: "library" },
  { id: "search",     label: "검색",       en: "Search",     icon: "search" },
  { id: "figures",    label: "Figure",     en: "Figures",    icon: "images" },
  { id: "chat",       label: "채팅",       en: "Chat",       icon: "message-square" },
  { id: "notes",      label: "노트",        en: "Notes",      icon: "sticky-note" },
  { id: "processing", label: "처리",        en: "Processing", icon: "cpu" },
];

const NavButton = ({ active, icon, label, count, onClick }) => (
  <button
    onClick={onClick}
    style={{
      display: "flex", alignItems: "center", gap: 9,
      padding: "7px 10px", width: "100%",
      borderRadius: "var(--radius-sm)", border: "none",
      cursor: "pointer", textAlign: "left",
      background: active ? "var(--color-accent-subtle)" : "transparent",
      color: active ? "var(--color-accent)" : "var(--color-text-secondary)",
      fontSize: 13,
      fontWeight: active ? 500 : 400,
      transition: "background var(--transition-fast), color var(--transition-fast)",
      marginBottom: 1,
    }}
  >
    <Icon name={icon} size={15} color={active ? "var(--color-accent)" : "var(--color-text-muted)"} />
    <span style={{ flex: 1 }}>{label}</span>
    {typeof count === "number" ? (
      <span style={{ fontSize: 10.5, color: "var(--color-text-muted)", fontVariantNumeric: "tabular-nums" }}>
        {count}
      </span>
    ) : null}
  </button>
);

const FolderTree = ({ activeFolderId, setActiveFolderId }) => {
  return (
    <div style={{ display: "grid", gap: 8 }}>
      <div style={{
        padding: "4px 10px", fontSize: 10, fontWeight: 700,
        letterSpacing: "0.08em", textTransform: "uppercase",
        color: "var(--color-text-muted)",
      }}>
        Folders · 폴더
      </div>
      <div style={{ display: "grid", gap: 2 }}>
        <NavButton
          active={!activeFolderId}
          icon="layers"
          label="All Papers"
          count={MOCK_PAPERS.length}
          onClick={() => setActiveFolderId(null)}
        />
        {MOCK_FOLDERS.map((f) => (
          <NavButton
            key={f.id}
            active={activeFolderId === f.id}
            icon={f.builtin ? (f.id === "starred" ? "star" : "clock-3") : "folder"}
            label={f.name}
            count={f.count}
            onClick={() => setActiveFolderId(f.id)}
          />
        ))}
      </div>
    </div>
  );
};

const LeftSidebar = ({ activeNav, setActiveNav, activeFolderId, setActiveFolderId }) => {
  return (
    <aside style={{
      width: "var(--sidebar-width)", minWidth: "var(--sidebar-width)",
      background: "var(--color-bg-panel)",
      borderRight: "1px solid var(--color-border-subtle)",
      display: "flex", flexDirection: "column",
      height: "100%", overflow: "hidden",
    }}>
      <div style={{
        height: "var(--topbar-height)",
        display: "flex", alignItems: "center",
        padding: "0 14px", gap: 7,
        borderBottom: "1px solid var(--color-border-subtle)",
        flexShrink: 0,
      }}>
        <img src="../../assets/Redou.png" alt="Redou" style={{
          width: 35, height: 35, borderRadius: "var(--radius-sm)",
        }} />
        <span style={{
          fontSize: 16, fontWeight: 600,
          color: "var(--color-text-primary)",
          letterSpacing: "-0.01em",
        }}>Redou</span>
      </div>

      <div style={{ padding: "8px 8px 0", flexShrink: 0 }}>
        {NAV_ITEMS.map((item) => (
          <NavButton
            key={item.id}
            active={activeNav === item.id}
            icon={item.icon}
            label={item.label}
            onClick={() => setActiveNav(item.id)}
          />
        ))}
      </div>

      <div style={{ height: 1, background: "var(--color-border-subtle)", margin: "8px 0", flexShrink: 0 }} />

      <div className="scroll-y" style={{ flex: 1, padding: "0 8px", minHeight: 0 }}>
        {activeNav === "library" ? (
          <FolderTree activeFolderId={activeFolderId} setActiveFolderId={setActiveFolderId} />
        ) : activeNav === "chat" ? (
          <div style={{ display: "grid", gap: 8 }}>
            <div style={{
              padding: "4px 10px", fontSize: 10, fontWeight: 700,
              letterSpacing: "0.08em", textTransform: "uppercase",
              color: "var(--color-text-muted)",
            }}>Conversations</div>
            <NavButton active icon="table-2" label="Zeolite kinetic 비교" />
            <NavButton icon="message-circle-question" label="MineRU vs GROBID" />
            <NavButton icon="message-circle-question" label="Transformer scaling laws" />
          </div>
        ) : (
          <div style={{ padding: "4px 10px", fontSize: 11.5, color: "var(--color-text-muted)" }}>
            Switch to Library or Chat for sidebar content.
          </div>
        )}
      </div>

      <div style={{ height: 1, background: "var(--color-border-subtle)", flexShrink: 0 }} />
      <div style={{ padding: 8 }}>
        <NavButton
          active={activeNav === "settings"}
          icon="settings"
          label="설정"
          onClick={() => setActiveNav("settings")}
        />
      </div>
    </aside>
  );
};

window.LeftSidebar = LeftSidebar;
