// SearchView — redesigned with command-bar feel, counted chips, grouped results,
// recent searches, and keyboard hints. More opinionated and scannable than the
// codebase version.

const RECENT_SEARCHES = [
  { q: "zeolite kinetic 비교",   ts: "2시간 전", count: 14 },
  { q: "transformer attention",   ts: "어제",     count: 32 },
  { q: "k_cat activation energy", ts: "3일 전",   count: 8 },
  { q: "MinerU vs GROBID",        ts: "1주 전",   count: 5 },
];

const TRY_PROMPTS = [
  "zeolite kinetic data 비교",
  "RAG hallucination detection",
  "transformer scaling laws",
  "활성화 에너지 78 kJ/mol",
];

const MOCK_RESULTS = [
  {
    paperId: "p1",
    source: "content",
    score: 0.91,
    page: 5,
    snippet: "The intrinsic alkylation rate constant **k_cat = 4.2 × 10⁻³ s⁻¹** was obtained at 320 °C with an apparent activation energy of 78 kJ mol⁻¹ over the range 290–340 °C.",
  },
  {
    paperId: "p1",
    source: "highlight",
    score: 0.88,
    page: 5,
    color: "rgba(15,118,110,0.5)",
    snippet: "k_cat = 4.2 × 10⁻³ s⁻¹ at 320 °C",
  },
  {
    paperId: "p1",
    source: "note",
    page: 3,
    score: 0.62,
    snippet: "다른 zeolite ratio에서 비교 필요. 320 °C가 sweet spot으로 보임.",
  },
  {
    paperId: "p1",
    source: "figure",
    page: 6,
    score: 0.71,
    snippet: "Figure 2 — Arrhenius plot for benzene alkylation over H-ZSM-5.",
  },
  {
    paperId: "p2",
    source: "title",
    score: 0.81,
    snippet: "Retrieval-augmented generation for multi-paper comparison tables",
  },
  {
    paperId: "p2",
    source: "content",
    score: 0.74,
    page: 4,
    snippet: "The retriever returns the top-**k chunks** ranked by cosine similarity in the pgvector index, with a kinetic-temperature fallback for noisy embeddings.",
  },
  {
    paperId: "p3",
    source: "content",
    score: 0.66,
    page: 2,
    snippet: "MinerU's structured parsing preserves **kinetic** equations and table cells with their original LaTeX, unlike GROBID which strips them.",
  },
  {
    paperId: "p3",
    source: "figure",
    page: 7,
    score: 0.52,
    snippet: "Table 3 — Comparison of extraction accuracy across kinetic chemistry papers.",
  },
];

const SOURCE_META = {
  title:     { label: "Title",     ko: "제목",      icon: "file-text",  color: "var(--color-accent)" },
  content:   { label: "Content",   ko: "본문",      icon: "file-search", color: "var(--color-text-secondary)" },
  highlight: { label: "Highlight", ko: "하이라이트", icon: "highlighter", color: "#f59e0b" },
  note:      { label: "Note",      ko: "노트",      icon: "sticky-note", color: "#a855f7" },
  figure:    { label: "Figure",    ko: "Figure",   icon: "images",      color: "#22d3a0" },
};

const SearchView = () => {
  const [query, setQuery]         = React.useState("kinetic");
  const [scope, setScope]         = React.useState("all");
  const [mode, setMode]           = React.useState("semantic");
  const inputRef                  = React.useRef(null);

  React.useEffect(() => {
    if (inputRef.current) inputRef.current.focus();
  }, []);

  const hasQuery = query.trim().length > 0;
  const paperMap = React.useMemo(
    () => new Map(MOCK_PAPERS.map((p) => [p.id, p])),
    []
  );

  const filtered = React.useMemo(() => {
    if (!hasQuery) return [];
    return MOCK_RESULTS.filter((r) => scope === "all" || r.source === scope);
  }, [scope, hasQuery]);

  const grouped = React.useMemo(() => {
    if (scope !== "all") return null;
    const g = {};
    for (const r of filtered) {
      (g[r.source] ||= []).push(r);
    }
    return g;
  }, [filtered, scope]);

  const counts = React.useMemo(() => {
    const c = { all: MOCK_RESULTS.length };
    for (const r of MOCK_RESULTS) c[r.source] = (c[r.source] || 0) + 1;
    return c;
  }, []);

  return (
    <div className="scroll-y" style={{ height: "100%", background: "var(--color-bg-surface)" }}>
      <div style={{ maxWidth: 820, margin: "0 auto", padding: "32px 24px 80px" }}>

        {/* ── Command bar ── */}
        <CommandBar
          query={query}
          setQuery={setQuery}
          inputRef={inputRef}
          mode={mode}
          setMode={setMode}
          resultCount={filtered.length}
        />

        {/* ── Scope chips ── */}
        {hasQuery ? (
          <ScopeChips scope={scope} setScope={setScope} counts={counts} />
        ) : null}

        {/* ── Empty state ── */}
        {!hasQuery ? <EmptyState setQuery={setQuery} /> : null}

        {/* ── Results ── */}
        {hasQuery && filtered.length > 0 ? (
          grouped ? (
            <GroupedResults grouped={grouped} paperMap={paperMap} />
          ) : (
            <FlatResults results={filtered} paperMap={paperMap} />
          )
        ) : null}

        {hasQuery && filtered.length === 0 ? <NoResults query={query} /> : null}

        {/* ── Keyboard hints ── */}
        <KeyboardHints />
      </div>
    </div>
  );
};

/* ──────────────────────────────────────────────
   Command bar (the big hero input)
   ────────────────────────────────────────────── */
const CommandBar = ({ query, setQuery, inputRef, mode, setMode, resultCount }) => {
  const hasQuery = query.trim().length > 0;
  return (
    <>
      <div className="eyebrow" style={{ marginBottom: 10 }}>Search · 검색</div>

      <div style={{
        display: "flex", alignItems: "center", gap: 12,
        padding: "0 18px",
        height: 54,
        borderRadius: "var(--radius-lg)",
        background: "var(--color-bg-elevated)",
        border: `1.5px solid ${hasQuery ? "var(--color-accent)" : "var(--color-border)"}`,
        boxShadow: hasQuery ? "0 0 0 4px var(--color-accent-subtle)" : "var(--shadow-sm)",
        transition: "border-color 150ms, box-shadow 150ms",
      }}>
        <Icon name="search" size={18} color={hasQuery ? "var(--color-accent)" : "var(--color-text-muted)"} />
        <input
          ref={inputRef}
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="논문, 본문, 노트, 하이라이트, Figure 검색…"
          style={{
            flex: 1, background: "transparent", border: "none", outline: "none",
            color: "var(--color-text-primary)", fontSize: 17, fontWeight: 400,
            letterSpacing: "-0.005em",
          }}
        />

        {hasQuery ? (
          <>
            <span style={{
              fontSize: 11.5, color: "var(--color-text-muted)",
              fontVariantNumeric: "tabular-nums",
            }}>
              {resultCount} results
            </span>
            <button
              onClick={() => { setQuery(""); inputRef.current?.focus(); }}
              style={{
                width: 26, height: 26,
                background: "var(--color-bg-hover)", border: "none",
                borderRadius: "var(--radius-sm)", cursor: "pointer",
                color: "var(--color-text-muted)",
                display: "flex", alignItems: "center", justifyContent: "center",
              }}
            ><Icon name="x" size={13} /></button>
          </>
        ) : (
          <kbd style={{
            fontFamily: "var(--font-mono)", fontSize: 11,
            padding: "3px 7px",
            background: "var(--color-bg-panel)",
            border: "1px solid var(--color-border-subtle)",
            borderRadius: "var(--radius-xs)",
            color: "var(--color-text-muted)",
            fontVariantNumeric: "tabular-nums",
          }}>⌘ K</kbd>
        )}
      </div>

      {/* Mode toggle */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        marginTop: 12, marginBottom: hasQuery ? 18 : 28,
      }}>
        <SegmentedTabs
          value={mode}
          onChange={setMode}
          options={[
            { value: "semantic", label: "Semantic", icon: "sparkles" },
            { value: "keyword",  label: "Keyword",  icon: "type" },
          ]}
        />
        <span style={{ fontSize: 11.5, color: "var(--color-text-muted)" }}>
          {mode === "semantic"
            ? "all-MiniLM-L6-v2 임베딩 기반 의미 검색"
            : "정확한 문자열 매칭"}
        </span>
        <div style={{ flex: 1 }} />
        <button style={{
          display: "inline-flex", alignItems: "center", gap: 5,
          padding: "4px 9px",
          background: "transparent",
          border: "1px solid var(--color-border-subtle)",
          borderRadius: "var(--radius-sm)",
          color: "var(--color-text-muted)",
          fontSize: 11.5, cursor: "pointer",
          whiteSpace: "nowrap",
        }}>
          <Icon name="filter" size={11} />
          전체 라이브러리
          <Icon name="chevron-down" size={11} />
        </button>
      </div>
    </>
  );
};

const SegmentedTabs = ({ value, onChange, options }) => (
  <div style={{
    display: "inline-flex",
    background: "var(--color-bg-panel)",
    border: "1px solid var(--color-border-subtle)",
    borderRadius: "var(--radius-sm)",
    padding: 2, gap: 2,
  }}>
    {options.map((o) => {
      const active = value === o.value;
      return (
        <button
          key={o.value}
          onClick={() => onChange(o.value)}
          style={{
            display: "inline-flex", alignItems: "center", gap: 5,
            padding: "4px 10px", border: "none",
            borderRadius: "var(--radius-xs)",
            background: active ? "var(--color-bg-elevated)" : "transparent",
            color: active ? "var(--color-accent)" : "var(--color-text-muted)",
            fontSize: 11.5, fontWeight: active ? 600 : 500,
            cursor: "pointer",
            boxShadow: active ? "0 1px 3px rgba(15,23,42,0.08)" : "none",
          }}
        >
          <Icon name={o.icon} size={11} />
          {o.label}
        </button>
      );
    })}
  </div>
);

/* ──────────────────────────────────────────────
   Scope chips (with counts)
   ────────────────────────────────────────────── */
const ScopeChips = ({ scope, setScope, counts }) => {
  const chips = [
    { id: "all",       label: "전체",     en: "All" },
    { id: "title",     label: "제목",     en: "Title" },
    { id: "content",   label: "본문",     en: "Content" },
    { id: "highlight", label: "하이라이트", en: "Highlights" },
    { id: "note",      label: "노트",     en: "Notes" },
    { id: "figure",    label: "Figure",  en: "Figures" },
  ];
  return (
    <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 22 }}>
      {chips.map((c) => {
        const active = scope === c.id;
        const count = counts[c.id] || 0;
        const meta = SOURCE_META[c.id];
        return (
          <button
            key={c.id}
            onClick={() => setScope(c.id)}
            style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              padding: "5px 11px",
              borderRadius: 999,
              fontSize: 11.5,
              fontWeight: active ? 600 : 500,
              border: active ? "1.5px solid var(--color-accent)" : "1px solid var(--color-border-subtle)",
              background: active ? "var(--color-accent-subtle)" : "var(--color-bg-elevated)",
              color: active ? "var(--color-accent)" : "var(--color-text-secondary)",
              cursor: "pointer",
              transition: "all 120ms",
              opacity: count === 0 && c.id !== "all" ? 0.45 : 1,
              whiteSpace: "nowrap",
            }}
            disabled={count === 0 && c.id !== "all"}
          >
            {meta ? <Icon name={meta.icon} size={11} color={active ? "var(--color-accent)" : meta.color} /> : null}
            {c.label}
            <span style={{
              fontVariantNumeric: "tabular-nums",
              fontSize: 10.5,
              color: active ? "var(--color-accent)" : "var(--color-text-muted)",
              opacity: 0.8,
            }}>{count}</span>
          </button>
        );
      })}
    </div>
  );
};

/* ──────────────────────────────────────────────
   Empty state
   ────────────────────────────────────────────── */
const EmptyState = ({ setQuery }) => (
  <div style={{ display: "grid", gap: 30 }}>
    {/* Try chips */}
    <section>
      <div className="eyebrow" style={{ marginBottom: 10 }}>Try · 이렇게 검색해보세요</div>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
        {TRY_PROMPTS.map((p) => (
          <button
            key={p}
            onClick={() => setQuery(p)}
            style={{
              display: "inline-flex", alignItems: "center", gap: 5,
              padding: "6px 12px",
              borderRadius: 999,
              border: "1px solid var(--color-border-subtle)",
              background: "var(--color-bg-elevated)",
              color: "var(--color-text-secondary)",
              fontSize: 12, cursor: "pointer",
              transition: "all var(--transition-fast)",
              whiteSpace: "nowrap",
            }}
          >
            <Icon name="sparkles" size={11} color="var(--color-accent)" />
            {p}
          </button>
        ))}
      </div>
    </section>

    {/* Recent searches */}
    <section>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <Icon name="history" size={13} color="var(--color-text-muted)" />
        <span className="eyebrow" style={{ marginBottom: 0 }}>Recent · 최근 검색</span>
        <div style={{ flex: 1 }} />
        <button style={{
          background: "transparent", border: "none", cursor: "pointer",
          color: "var(--color-text-muted)", fontSize: 11, fontWeight: 500,
        }}>Clear all</button>
      </div>
      <div style={{ display: "grid", gap: 4 }}>
        {RECENT_SEARCHES.map((r) => (
          <button
            key={r.q}
            onClick={() => setQuery(r.q)}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              padding: "9px 12px",
              borderRadius: "var(--radius-sm)",
              border: "1px solid transparent",
              background: "transparent",
              color: "var(--color-text-primary)",
              cursor: "pointer", textAlign: "left",
              transition: "background var(--transition-fast)",
            }}
            onMouseEnter={(e) => { e.currentTarget.style.background = "var(--color-bg-hover)"; }}
            onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
          >
            <Icon name="search" size={13} color="var(--color-text-muted)" />
            <span style={{ flex: 1, fontSize: 13 }}>{r.q}</span>
            <span style={{ fontSize: 11, color: "var(--color-text-muted)", fontVariantNumeric: "tabular-nums" }}>{r.count}건</span>
            <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>·</span>
            <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>{r.ts}</span>
            <button
              onClick={(e) => e.stopPropagation()}
              style={{
                background: "transparent", border: "none", cursor: "pointer",
                color: "var(--color-text-muted)", opacity: 0.5,
                width: 18, height: 18,
                display: "flex", alignItems: "center", justifyContent: "center",
              }}
            ><Icon name="x" size={11} /></button>
          </button>
        ))}
      </div>
    </section>

    {/* Recent papers */}
    <section>
      <div className="eyebrow" style={{ marginBottom: 10 }}>Recent papers · 최근 논문</div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 8 }}>
        {MOCK_PAPERS.slice(0, 4).map((p) => (
          <button
            key={p.id}
            style={{
              display: "flex", alignItems: "flex-start", gap: 10,
              padding: "12px 14px",
              border: "1px solid var(--color-border-subtle)",
              background: "var(--color-bg-elevated)",
              borderRadius: "var(--radius-md)",
              textAlign: "left", cursor: "pointer",
            }}
          >
            <div style={{
              width: 32, height: 32, borderRadius: "var(--radius-sm)",
              background: "var(--color-accent-subtle)",
              display: "flex", alignItems: "center", justifyContent: "center",
              color: "var(--color-accent)", flexShrink: 0,
            }}><Icon name="file-text" size={14} /></div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{
                fontSize: 12.5, fontWeight: 600, color: "var(--color-text-primary)",
                lineHeight: 1.4, marginBottom: 3,
                display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden",
              }}>{p.title}</div>
              <div style={{ fontSize: 11, color: "var(--color-text-muted)" }}>
                {p.venue} · {p.year}
              </div>
            </div>
          </button>
        ))}
      </div>
    </section>
  </div>
);

/* ──────────────────────────────────────────────
   Results — grouped and flat
   ────────────────────────────────────────────── */
const GroupedResults = ({ grouped, paperMap }) => {
  const order = ["title", "content", "highlight", "note", "figure"];
  return (
    <div style={{ display: "grid", gap: 20 }}>
      {order.map((src) => {
        const items = grouped[src];
        if (!items || items.length === 0) return null;
        const meta = SOURCE_META[src];
        return (
          <section key={src}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8,
              marginBottom: 8,
            }}>
              <Icon name={meta.icon} size={13} color={meta.color} />
              <span style={{
                fontSize: 11, fontWeight: 700,
                color: "var(--color-text-secondary)",
                letterSpacing: "0.08em", textTransform: "uppercase",
              }}>{meta.label} · {meta.ko}</span>
              <span style={{
                fontSize: 10.5, color: "var(--color-text-muted)",
                background: "var(--color-bg-panel)",
                padding: "1px 6px", borderRadius: "var(--radius-xs)",
                fontVariantNumeric: "tabular-nums",
              }}>{items.length}</span>
              <div style={{ flex: 1, height: 1, background: "var(--color-border-subtle)" }} />
            </div>
            <div style={{ display: "grid", gap: 6 }}>
              {items.map((r, i) => (
                <ResultCard key={r.paperId + i} result={r} paper={paperMap.get(r.paperId)} />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
};

const FlatResults = ({ results, paperMap }) => (
  <div style={{ display: "grid", gap: 6 }}>
    {results.map((r, i) => (
      <ResultCard key={r.paperId + i} result={r} paper={paperMap.get(r.paperId)} />
    ))}
  </div>
);

const ResultCard = ({ result, paper }) => {
  const meta   = SOURCE_META[result.source];
  const score  = Math.round(result.score * 100);
  const strong = score > 80;
  const ok     = score > 50 && score <= 80;

  // Render the snippet with **bold** markdown turned into highlighted spans.
  const parts = (result.snippet || "").split(/(\*\*[^*]+\*\*)/g).filter(Boolean);

  return (
    <button style={{
      display: "flex", gap: 12,
      padding: "12px 14px",
      width: "100%",
      border: "1px solid var(--color-border-subtle)",
      background: "var(--color-bg-elevated)",
      borderRadius: "var(--radius-md)",
      textAlign: "left", cursor: "pointer",
      transition: "border-color var(--transition-fast)",
    }}
      onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--color-border)"; }}
      onMouseLeave={(e) => { e.currentTarget.style.borderColor = "var(--color-border-subtle)"; }}
    >
      {/* Left source rail */}
      <div style={{
        width: 32, flexShrink: 0,
        display: "flex", flexDirection: "column", alignItems: "center", gap: 6,
      }}>
        <div style={{
          width: 28, height: 28, borderRadius: "var(--radius-sm)",
          background: `color-mix(in oklab, ${meta.color} 12%, transparent)`,
          display: "flex", alignItems: "center", justifyContent: "center",
          color: meta.color,
        }}><Icon name={meta.icon} size={14} /></div>
        {result.page ? (
          <span style={{
            fontSize: 10, color: "var(--color-text-muted)",
            fontVariantNumeric: "tabular-nums", fontWeight: 600,
          }}>p.{result.page}</span>
        ) : null}
      </div>

      {/* Main */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          display: "flex", alignItems: "baseline", gap: 8, marginBottom: 4,
        }}>
          <span style={{
            fontSize: 12.5, fontWeight: 600,
            color: "var(--color-text-primary)",
            whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
            flex: 1, minWidth: 0,
          }}>{paper?.title || "Unknown paper"}</span>
          <span style={{
            fontSize: 10.5, color: "var(--color-text-muted)", flexShrink: 0,
          }}>{paper?.venue} · {paper?.year}</span>
        </div>

        {result.source !== "title" ? (
          <div style={{
            fontSize: 12.5, lineHeight: 1.6,
            color: "var(--color-text-secondary)",
            borderLeft: result.color ? `3px solid ${result.color}` : "3px solid var(--color-border-subtle)",
            paddingLeft: 10,
            display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
            overflow: "hidden",
          }}>
            {parts.map((part, i) => {
              if (part.startsWith("**")) {
                return (
                  <mark
                    key={i}
                    style={{
                      background: "rgba(245,158,11,0.32)",
                      padding: "1px 3px", borderRadius: 2, color: "inherit",
                      fontWeight: 600,
                    }}
                  >{part.slice(2, -2)}</mark>
                );
              }
              return <span key={i}>{part}</span>;
            })}
          </div>
        ) : null}
      </div>

      {/* Score */}
      <div style={{
        flexShrink: 0, display: "flex", flexDirection: "column",
        alignItems: "flex-end", justifyContent: "space-between", gap: 4,
      }}>
        <span style={{
          fontSize: 11, fontWeight: 700,
          padding: "2px 8px", borderRadius: 999,
          background: strong ? "rgba(15,118,110,0.12)" : ok ? "var(--color-accent-subtle)" : "var(--color-bg-panel)",
          color:       strong ? "var(--color-success)"  : ok ? "var(--color-accent)"        : "var(--color-text-muted)",
          fontVariantNumeric: "tabular-nums",
        }}>{score}%</span>
        <span style={{
          fontSize: 10.5, color: "var(--color-text-muted)",
          display: "inline-flex", alignItems: "center", gap: 3,
        }}>
          Open <Icon name="arrow-right" size={10} />
        </span>
      </div>
    </button>
  );
};

const NoResults = ({ query }) => (
  <div style={{
    display: "flex", flexDirection: "column", alignItems: "center",
    justifyContent: "center", gap: 10, minHeight: 200,
    border: "1px dashed var(--color-border)",
    borderRadius: "var(--radius-lg)",
    color: "var(--color-text-muted)",
    padding: 20,
  }}>
    <Icon name="search-x" size={28} color="var(--color-text-muted)" style={{ opacity: 0.4 }} />
    <div style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>
      <strong style={{ color: "var(--color-text-primary)" }}>"{query}"</strong> 에 대한 결과가 없습니다.
    </div>
    <div style={{ fontSize: 11.5, color: "var(--color-text-muted)", textAlign: "center", lineHeight: 1.65, maxWidth: 320 }}>
      Semantic 모드로 시도해보거나, 필터를 풀어보세요.<br />
      라이브러리에 더 많은 논문을 추가하면 검색 결과가 풍부해집니다.
    </div>
  </div>
);

/* ──────────────────────────────────────────────
   Keyboard hints
   ────────────────────────────────────────────── */
const KeyboardHints = () => (
  <div style={{
    display: "flex", alignItems: "center", justifyContent: "center", gap: 18,
    marginTop: 40, paddingTop: 18,
    borderTop: "1px solid var(--color-border-subtle)",
    color: "var(--color-text-muted)",
    fontSize: 11,
  }}>
    {[
      { keys: ["↑", "↓"], label: "navigate" },
      { keys: ["⏎"],       label: "open" },
      { keys: ["⌘", "K"], label: "focus search" },
      { keys: ["⎋"],       label: "clear" },
    ].map((hint, i) => (
      <span key={i} style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
        {hint.keys.map((k) => (
          <kbd key={k} style={{
            fontFamily: "var(--font-mono)", fontSize: 10,
            padding: "2px 6px",
            background: "var(--color-bg-elevated)",
            border: "1px solid var(--color-border-subtle)",
            borderRadius: "var(--radius-xs)",
            color: "var(--color-text-secondary)",
            minWidth: 18, textAlign: "center", display: "inline-block",
          }}>{k}</kbd>
        ))}
        <span>{hint.label}</span>
      </span>
    ))}
  </div>
);

window.SearchView = SearchView;
