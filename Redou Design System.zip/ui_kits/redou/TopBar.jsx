// TopBar — breadcrumb, search field, sort, view-mode toggle, inspector, add-paper primary.

const IconButton = ({ active, size = "md", onClick, children, ariaLabel }) => {
  const dim = size === "sm" ? 26 : 30;
  const [hover, setHover] = React.useState(false);
  return (
    <button
      onClick={onClick}
      aria-label={ariaLabel}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        display: "inline-flex", alignItems: "center", justifyContent: "center",
        width: dim, height: dim,
        borderRadius: "var(--radius-sm)",
        border: "none", cursor: "pointer", flexShrink: 0,
        background: active
          ? "var(--color-accent-subtle)"
          : hover ? "var(--color-bg-hover)" : "transparent",
        color: active
          ? "var(--color-accent)"
          : hover ? "var(--color-text-secondary)" : "var(--color-text-muted)",
        transition: "background var(--transition-fast), color var(--transition-fast)",
      }}
    >{children}</button>
  );
};
window.IconButton = IconButton;

const TopBar = ({
  breadcrumb, searchQuery, setSearchQuery,
  sortKey, setSortKey, viewMode, setViewMode,
  inspectorOpen, toggleInspector, showLibraryControls, showBack, onBack,
  onAddPaper, hideSearch,
}) => {
  const sortOptions = [
    { value: "addedAt", label: "추가일" },
    { value: "year", label: "Year" },
    { value: "title", label: "Title" },
    { value: "citations", label: "Citations" },
  ];

  return (
    <header style={{
      height: "var(--topbar-height)",
      background: "var(--color-bg-surface)",
      borderBottom: "1px solid var(--color-border-subtle)",
      display: "flex", alignItems: "center",
      padding: "0 14px", gap: 10, flexShrink: 0,
    }}>
      <div style={{ minWidth: 120, maxWidth: 300, flexShrink: 0 }}>
        <span title={breadcrumb} style={{
          display: "block", fontSize: 14, fontWeight: 600,
          color: "var(--color-text-primary)", letterSpacing: "-0.01em",
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        }}>{breadcrumb}</span>
      </div>

      {/* search */}
      {hideSearch ? (
        <div style={{ flex: 1 }} />
      ) : (
      <div style={{
        flex: 1, maxWidth: 460, height: 32,
        display: "flex", alignItems: "center", gap: 8, padding: "0 10px",
        background: "var(--color-bg-elevated)",
        border: "1px solid var(--color-border-subtle)",
        borderRadius: "var(--radius-md)",
      }}>
        <Icon name="search" size={14} color="var(--color-text-muted)" />
        <input
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          placeholder="논문, 저자, 태그 검색"
          style={{
            flex: 1, background: "transparent", border: "none", outline: "none",
            color: "var(--color-text-primary)", fontSize: 13,
          }}
        />
        {searchQuery ? (
          <button
            onClick={() => setSearchQuery("")}
            style={{
              background: "transparent", border: "none", cursor: "pointer",
              color: "var(--color-text-muted)", fontSize: 11, fontWeight: 600,
            }}
          >Clear</button>
        ) : null}
      </div>
      )}

      <div style={{ flex: 1 }} />

      {showLibraryControls ? (
        <>
          <select
            value={sortKey}
            onChange={(e) => setSortKey(e.target.value)}
            style={{
              height: 30, padding: "0 10px",
              borderRadius: "var(--radius-sm)",
              border: "1px solid var(--color-border-subtle)",
              background: "var(--color-bg-elevated)",
              color: "var(--color-text-secondary)",
              fontSize: 12, cursor: "pointer",
            }}
          >
            {sortOptions.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
          </select>

          <IconButton ariaLabel="Filters">
            <Icon name="sliders-horizontal" size={14} />
          </IconButton>

          <div style={{
            display: "flex",
            background: "var(--color-bg-elevated)",
            border: "1px solid var(--color-border-subtle)",
            borderRadius: "var(--radius-sm)",
            padding: 2, gap: 2,
          }}>
            <IconButton size="sm" active={viewMode === "grid"} onClick={() => setViewMode("grid")} ariaLabel="Grid view">
              <Icon name="layout-grid" size={13} />
            </IconButton>
            <IconButton size="sm" active={viewMode === "list"} onClick={() => setViewMode("list")} ariaLabel="List view">
              <Icon name="list" size={13} />
            </IconButton>
          </div>

          <button
            onClick={onAddPaper}
            style={{
              display: "flex", alignItems: "center", gap: 5,
              padding: "0 12px", height: 30,
              borderRadius: "var(--radius-sm)", border: "none",
              background: "var(--color-accent)", color: "#fff",
              fontSize: 12, fontWeight: 500, cursor: "pointer",
              whiteSpace: "nowrap",
            }}
          >
            <Icon name="plus" size={13} />
            Add Paper
          </button>
        </>
      ) : null}

      {showBack ? (
        <button
          onClick={onBack}
          style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            height: 30, padding: "0 12px",
            borderRadius: "var(--radius-sm)",
            border: "1px solid var(--color-border-subtle)",
            background: "var(--color-bg-elevated)",
            color: "var(--color-text-secondary)",
            cursor: "pointer", fontSize: 12,
          }}
        >
          <Icon name="arrow-left" size={13} />
          라이브러리로
        </button>
      ) : null}

      <IconButton active={inspectorOpen} onClick={toggleInspector} ariaLabel="Toggle inspector">
        <Icon name={inspectorOpen ? "panel-right-close" : "panel-right-open"} size={15} />
      </IconButton>
    </header>
  );
};

window.TopBar = TopBar;
