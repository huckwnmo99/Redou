// NotesView — Apple Notes / Linear-style 3-pane layout.
// Left: kind filter + sort. Middle: scrollable note list with search.
// Right: big calm editor with meta chips strip.

const NOTE_KINDS = {
  summary:    { label: "Summary",    ko: "요약",   color: "#2563eb", icon: "file-text" },
  question:   { label: "Question",   ko: "질문",   color: "#a855f7", icon: "help-circle" },
  idea:       { label: "Idea",       ko: "아이디어", color: "#f59e0b", icon: "lightbulb" },
  comparison: { label: "Comparison", ko: "비교",   color: "#0f766e", icon: "git-compare" },
  quote:      { label: "Quote",      ko: "인용",   color: "#52627c", icon: "quote" },
  todo:       { label: "Todo",       ko: "할 일",  color: "#dc2626", icon: "circle-check" },
};

const MOCK_NOTES = [
  {
    id: "n1", paperId: "p1", kind: "question",
    title: "Open question — coking onset",
    page: 5,
    anchorQuote: "deactivation slope changes above 350 °C",
    content: "Figure 2 위 350 °C에서 deactivation slope이 갑자기 바뀜. mechanism 가설?\n\n- coking이 가속화되는 임계 온도?\n- pore mouth blocking?\n- secondary cracking 시작?",
    updatedAt: "2시간 전",
    pinned: true,
  },
  {
    id: "n2", paperId: "p1", kind: "summary",
    title: "Reaction conditions vs Park 2022",
    page: 3,
    content: "다른 zeolite ratio에서 비교 필요. 320 °C가 sweet spot으로 보임. Si/Al 23이 가장 안정적이고, intrinsic kinetics 추출 가능한 유일한 조건.",
    updatedAt: "어제",
  },
  {
    id: "n3", paperId: "p1", kind: "todo",
    title: "Method follow-up",
    page: 4,
    content: "- Mears criterion 다시 계산\n- particle size 250 µm 위는 측정 안 됨 → 추가 실험 필요\n- residence time 분포 확인",
    updatedAt: "3일 전",
  },
  {
    id: "n4", paperId: "p2", kind: "idea",
    title: "RAG 파이프라인에 Guardian 적용 가능?",
    content: "Granite Guardian을 chunk-level retrieval 결과에 바로 적용하면 'unverified' 표시가 검색 결과에도 나올 수 있을 것 같다. 비용 검토 필요.",
    updatedAt: "어제",
  },
  {
    id: "n5", paperId: "p2", kind: "quote",
    title: "Core claim",
    page: 4,
    anchorQuote: "The retriever returns the top-k chunks ranked by cosine similarity",
    content: "이 부분이 우리 인프라랑 가장 유사. 비교해서 어떤 부분 다르게 디자인 했는지 정리하기.",
    updatedAt: "2일 전",
  },
  {
    id: "n6", paperId: "p3", kind: "comparison",
    title: "MineRU vs GROBID 정확도",
    content: "Table 3에 따르면 kinetic chemistry papers에서 MineRU가 표 추출 17%p 더 높음. equation은 비슷. 우리는 둘 다 쓰니까 fallback chain 잘 디자인 됨.",
    updatedAt: "1주 전",
    pinned: true,
  },
  {
    id: "n7", paperId: "p3", kind: "todo",
    title: "MinerU Docker 메모리 튜닝",
    content: "- 현재 12 GB 할당\n- 큰 PDF (200+ pages) 처리 시 OOM\n- swap 늘리거나 16 GB로 올리기",
    updatedAt: "1주 전",
  },
];

const SORT_OPTIONS = [
  { value: "updated", label: "Last modified · 최종 수정" },
  { value: "created", label: "Created · 생성일" },
  { value: "title",   label: "Title · 제목" },
  { value: "kind",    label: "Kind · 종류" },
];

const NotesView = () => {
  const [kindFilter, setKindFilter]   = React.useState("all");
  const [paperFilter, setPaperFilter] = React.useState("all");
  const [sort, setSort]               = React.useState("updated");
  const [search, setSearch]           = React.useState("");
  const [activeId, setActiveId]       = React.useState("n1");

  const paperMap = React.useMemo(() => new Map(MOCK_PAPERS.map((p) => [p.id, p])), []);

  const filtered = React.useMemo(() => {
    let list = MOCK_NOTES;
    if (kindFilter  !== "all") list = list.filter((n) => n.kind === kindFilter);
    if (paperFilter !== "all") list = list.filter((n) => n.paperId === paperFilter);
    const q = search.trim().toLowerCase();
    if (q) list = list.filter((n) =>
      n.title.toLowerCase().includes(q) || n.content.toLowerCase().includes(q)
    );
    return list;
  }, [kindFilter, paperFilter, search]);

  const sorted = React.useMemo(() => {
    const s = [...filtered];
    // pinned first
    s.sort((a, b) => Number(b.pinned || 0) - Number(a.pinned || 0));
    return s;
  }, [filtered]);

  const active = sorted.find((n) => n.id === activeId) || sorted[0];

  const kindCounts = React.useMemo(() => {
    const c = { all: MOCK_NOTES.length };
    for (const n of MOCK_NOTES) c[n.kind] = (c[n.kind] || 0) + 1;
    return c;
  }, []);

  // Resizable divider between the list and the editor
  const MIN_W = 280, MAX_W = 560;
  const [listWidth, setListWidth] = React.useState(() => {
    const saved = Number(localStorage.getItem("redou.notes.listWidth"));
    return saved >= MIN_W && saved <= MAX_W ? saved : 360;
  });
  const dragRef = React.useRef(null);

  const startDrag = (e) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = listWidth;
    document.body.style.cursor = "col-resize";
    document.body.style.userSelect = "none";
    const onMove = (ev) => {
      const next = Math.min(MAX_W, Math.max(MIN_W, startW + (ev.clientX - startX)));
      setListWidth(next);
    };
    const onUp = () => {
      document.removeEventListener("mousemove", onMove);
      document.removeEventListener("mouseup", onUp);
      document.body.style.cursor = "";
      document.body.style.userSelect = "";
      setListWidth((w) => { localStorage.setItem("redou.notes.listWidth", String(w)); return w; });
    };
    document.addEventListener("mousemove", onMove);
    document.addEventListener("mouseup", onUp);
  };

  return (
    <div style={{ display: "flex", height: "100%", background: "var(--color-bg-surface)", overflow: "hidden" }}>
      {/* ── Left: combined list with filter strip on top ── */}
      <NoteList
        width={listWidth}
        notes={sorted}
        activeId={active?.id}
        setActiveId={setActiveId}
        paperMap={paperMap}
        search={search} setSearch={setSearch}
        kindFilter={kindFilter} setKindFilter={setKindFilter} kindCounts={kindCounts}
        paperFilter={paperFilter} setPaperFilter={setPaperFilter}
        sort={sort} setSort={setSort}
        onNew={() => {}}
      />

      {/* ── Drag-to-resize divider ── */}
      <ResizeHandle onMouseDown={startDrag} />

      {/* ── Right: editor ── */}
      {active ? (
        <NoteEditor note={active} paper={paperMap.get(active.paperId)} />
      ) : (
        <EmptyEditor />
      )}
    </div>
  );
};

/* ───────────────────────────────────
   Drag-to-resize divider
   ─────────────────────────────────── */
const ResizeHandle = ({ onMouseDown }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <div
      onMouseDown={onMouseDown}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      title="드래그하여 너비 조절"
      style={{
        position: "relative",
        width: 6, flexShrink: 0,
        marginLeft: -3, marginRight: -3, zIndex: 5,
        cursor: "col-resize",
        display: "flex", alignItems: "center", justifyContent: "center",
      }}
    >
      <div style={{
        width: 1, height: "100%",
        background: hover ? "var(--color-accent)" : "var(--color-border-subtle)",
        transition: "background var(--transition-fast)",
      }} />
      <div style={{
        position: "absolute",
        width: 4, height: 30, borderRadius: 999,
        background: hover ? "var(--color-accent)" : "transparent",
        transition: "background var(--transition-fast)",
      }} />
    </div>
  );
};

/* ──────────────────────────────────────────────
   List + integrated filter strip
   ────────────────────────────────────────────── */
const NoteList = ({
  width,
  notes, activeId, setActiveId, paperMap,
  search, setSearch,
  kindFilter, setKindFilter, kindCounts,
  paperFilter, setPaperFilter, sort, setSort,
  onNew,
}) => (
  <section style={{
    width, flexShrink: 0,
    background: "var(--color-bg-panel)",
    display: "flex", flexDirection: "column",
    overflow: "hidden",
    minWidth: 0,
  }}>
    {/* Header: title + count + new */}
    <header style={{
      padding: "14px 14px 0",
      flexShrink: 0,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
        <h2 style={{ fontSize: 16, fontWeight: 600, letterSpacing: "-0.01em", whiteSpace: "nowrap" }}>
          Notes · 노트
        </h2>
        <span style={{
          fontSize: 11, color: "var(--color-text-muted)",
          background: "var(--color-bg-elevated)",
          padding: "1px 7px", borderRadius: "var(--radius-xs)",
          fontVariantNumeric: "tabular-nums",
        }}>{notes.length}</span>
        <div style={{ flex: 1 }} />
        <button
          onClick={onNew}
          style={{
            display: "inline-flex", alignItems: "center", gap: 5,
            padding: "0 10px", height: 28,
            borderRadius: "var(--radius-sm)", border: "none",
            background: "var(--color-accent)", color: "#fff",
            fontSize: 12, fontWeight: 500, cursor: "pointer",
            whiteSpace: "nowrap", flexShrink: 0,
          }}
        >
          <Icon name="plus" size={12} />
          New
        </button>
      </div>

      {/* Search */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        padding: "0 10px", height: 30,
        background: "var(--color-bg-elevated)",
        border: "1px solid var(--color-border-subtle)",
        borderRadius: "var(--radius-sm)",
        marginBottom: 8,
      }}>
        <Icon name="search" size={12} color="var(--color-text-muted)" />
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="노트 검색…"
          style={{
            flex: 1, minWidth: 0,
            background: "transparent", border: "none", outline: "none",
            color: "var(--color-text-primary)", fontSize: 12.5,
          }}
        />
        {search ? (
          <button
            onClick={() => setSearch("")}
            style={{ background: "transparent", border: "none", cursor: "pointer", color: "var(--color-text-muted)", flexShrink: 0 }}
          ><Icon name="x" size={11} /></button>
        ) : null}
      </div>

      {/* Kind chips — wrap so every category stays visible */}
      <div style={{
        display: "flex", flexWrap: "wrap", gap: 4,
        marginBottom: 10,
      }}>
        <KindChip
          active={kindFilter === "all"}
          onClick={() => setKindFilter("all")}
          color="var(--color-text-muted)"
          label="전체"
          count={kindCounts.all}
        />
        {Object.entries(NOTE_KINDS).map(([id, k]) => (
          <KindChip
            key={id}
            active={kindFilter === id}
            onClick={() => setKindFilter(id)}
            color={k.color}
            label={k.label}
            count={kindCounts[id] || 0}
          />
        ))}
      </div>

      {/* Paper + Sort selects (compact row) */}
      <div style={{
        display: "flex", gap: 6, marginBottom: 10,
      }}>
        <CompactSelect
          value={paperFilter}
          onChange={setPaperFilter}
          options={[
            { value: "all", label: "전체 논문" },
            ...MOCK_PAPERS.map((p) => ({
              value: p.id,
              label: p.title.slice(0, 28) + (p.title.length > 28 ? "…" : ""),
            })),
          ]}
          icon="file-text"
        />
        <CompactSelect
          value={sort}
          onChange={setSort}
          options={SORT_OPTIONS.map((o) => ({ value: o.value, label: o.label.split(" · ")[1] || o.label }))}
          icon="arrow-up-down"
        />
      </div>
    </header>

    {/* List */}
    <div className="scroll-y" style={{ flex: 1, minHeight: 0, borderTop: "1px solid var(--color-border-subtle)" }}>
      {notes.length === 0 ? (
        <div style={{
          display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
          padding: "60px 24px",
          color: "var(--color-text-muted)", gap: 8, textAlign: "center",
        }}>
          <Icon name="search-x" size={24} color="var(--color-text-muted)" style={{ opacity: 0.4 }} />
          <div style={{ fontSize: 12.5 }}>매칭되는 노트가 없습니다.</div>
        </div>
      ) : (
        notes.map((note) => (
          <NoteCard
            key={note.id}
            note={note}
            paper={paperMap.get(note.paperId)}
            active={activeId === note.id}
            onClick={() => setActiveId(note.id)}
          />
        ))
      )}
    </div>
  </section>
);

const KindChip = ({ active, onClick, color, label, count }) => (
  <button
    onClick={onClick}
    style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "4px 9px",
      borderRadius: 999,
      border: active ? `1px solid ${color}` : "1px solid var(--color-border-subtle)",
      background: active ? `color-mix(in oklab, ${color} 12%, transparent)` : "var(--color-bg-elevated)",
      color: active ? color : "var(--color-text-secondary)",
      fontSize: 11, fontWeight: active ? 600 : 500,
      cursor: "pointer",
      flexShrink: 0,
      whiteSpace: "nowrap",
      transition: "all var(--transition-fast)",
    }}
  >
    <span style={{
      width: 6, height: 6, borderRadius: "50%",
      background: color, flexShrink: 0,
    }} />
    {label}
    <span style={{
      fontSize: 10, fontVariantNumeric: "tabular-nums",
      opacity: 0.75,
    }}>{count}</span>
  </button>
);

const CompactSelect = ({ value, onChange, options, icon }) => (
  <div style={{
    display: "flex", alignItems: "center", gap: 6,
    padding: "0 8px", height: 28,
    background: "var(--color-bg-elevated)",
    border: "1px solid var(--color-border-subtle)",
    borderRadius: "var(--radius-sm)",
    flex: 1, minWidth: 0,
  }}>
    <Icon name={icon} size={11} color="var(--color-text-muted)" />
    <select
      value={value}
      onChange={(e) => onChange(e.target.value)}
      style={{
        flex: 1, minWidth: 0,
        background: "transparent", border: "none", outline: "none",
        color: "var(--color-text-secondary)",
        fontSize: 11.5, cursor: "pointer",
        fontFamily: "var(--font-sans)",
        appearance: "none",
        paddingRight: 12,
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%238a96a9' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E")`,
        backgroundRepeat: "no-repeat",
        backgroundPosition: "right center",
      }}
    >
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  </div>
);

const NoteCard = ({ note, paper, active, onClick }) => {
  const kind = NOTE_KINDS[note.kind];
  return (
    <button
      onClick={onClick}
      style={{
        display: "flex", gap: 10,
        width: "100%", padding: "12px 14px",
        background: active ? "var(--color-bg-elevated)" : "transparent",
        borderLeft: `3px solid ${active ? kind.color : "transparent"}`,
        borderRight: "none", borderTop: "none",
        borderBottom: "1px solid var(--color-border-subtle)",
        cursor: "pointer", textAlign: "left",
        position: "relative",
      }}
    >
      <div style={{ flex: 1, minWidth: 0, display: "grid", gap: 4 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            fontSize: 10, fontWeight: 700, letterSpacing: "0.03em",
            color: kind.color,
          }}>
            <span style={{ width: 6, height: 6, borderRadius: 2, background: kind.color }} />
            {kind.label}
          </span>
          {note.pinned ? (
            <Icon name="pin" size={10} color="var(--color-warning)" style={{ transform: "rotate(35deg)" }} />
          ) : null}
          <div style={{ flex: 1 }} />
          <span style={{ fontSize: 10, color: "var(--color-text-muted)", whiteSpace: "nowrap", flexShrink: 0 }}>{note.updatedAt}</span>
        </div>

        <div style={{
          fontSize: 13, fontWeight: 600,
          color: "var(--color-text-primary)",
          lineHeight: 1.35,
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        }}>{note.title}</div>

        <div style={{
          fontSize: 11.5, color: "var(--color-text-secondary)",
          lineHeight: 1.55,
          display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical", overflow: "hidden",
        }}>{note.content}</div>

        <div style={{
          display: "flex", alignItems: "center", gap: 6,
          fontSize: 10.5, color: "var(--color-text-muted)",
          marginTop: 2, minWidth: 0,
        }}>
          <Icon name="file-text" size={10} color="var(--color-text-muted)" style={{ flexShrink: 0 }} />
          <span style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", flex: 1, minWidth: 0 }}>
            {paper?.title || "Unknown paper"}
          </span>
          {note.page ? (
            <span style={{ flexShrink: 0, fontVariantNumeric: "tabular-nums" }}>p.{note.page}</span>
          ) : null}
        </div>
      </div>
    </button>
  );
};

/* ──────────────────────────────────────────────
   Right pane — editor
   ────────────────────────────────────────────── */
const NoteEditor = ({ note, paper }) => {
  const kind = NOTE_KINDS[note.kind];
  return (
    <section style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden", background: "var(--color-bg-elevated)" }}>
      {/* Header */}
      <header style={{
        padding: "16px 28px 12px",
        borderBottom: "1px solid var(--color-border-subtle)",
        flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8 }}>
          <NoteKindChip kind={kind} interactive />
          <div style={{ flex: 1 }} />
          <SaveStatus />
          <IconButtonNotes name="pin" active={note.pinned} title="Pin" />
          <IconButtonNotes name="trash-2" title="Delete" danger />
        </div>

        <input
          key={note.id}
          defaultValue={note.title}
          placeholder="제목 없음"
          style={{
            width: "100%",
            background: "transparent",
            border: "none", outline: "none",
            fontSize: 24, fontWeight: 700,
            letterSpacing: "-0.02em",
            color: "var(--color-text-primary)",
            fontFamily: "var(--font-sans)",
            padding: "4px 0",
          }}
        />

        {/* Meta strip */}
        <div style={{
          display: "flex", flexWrap: "wrap", gap: 8,
          marginTop: 8, fontSize: 11.5,
          color: "var(--color-text-muted)",
        }}>
          <MetaChip icon="file-text" label={paper?.title || "Unknown paper"} link />
          {note.page ? <MetaChip icon="bookmark" label={`p.${note.page}`} accent /> : null}
          <MetaChip icon="clock" label={`수정 ${note.updatedAt}`} />
        </div>
      </header>

      {/* Linked-source banner */}
      {note.anchorQuote ? (
        <div style={{
          padding: "10px 28px",
          background: "var(--color-bg-surface)",
          borderBottom: "1px solid var(--color-border-subtle)",
          display: "flex", alignItems: "flex-start", gap: 10,
          fontSize: 12.5, color: "var(--color-text-secondary)", lineHeight: 1.65,
          flexShrink: 0,
        }}>
          <Icon name="quote" size={13} color="var(--color-text-muted)" style={{ marginTop: 2, flexShrink: 0 }} />
          <div style={{ flex: 1, fontStyle: "italic" }}>"{note.anchorQuote}"</div>
          <button style={{
            display: "inline-flex", alignItems: "center", gap: 4,
            padding: "3px 8px", height: 24,
            borderRadius: "var(--radius-xs)",
            border: "1px solid var(--color-border-subtle)",
            background: "var(--color-bg-elevated)",
            color: "var(--color-text-secondary)",
            fontSize: 11, fontWeight: 500, cursor: "pointer",
            flexShrink: 0, whiteSpace: "nowrap",
          }}>
            <Icon name="external-link" size={10} />
            소스로 이동
          </button>
        </div>
      ) : null}

      {/* Body */}
      <div className="scroll-y" style={{ flex: 1, padding: "20px 28px 40px" }}>
        <textarea
          key={note.id}
          defaultValue={note.content}
          placeholder="여기에 적기 시작하세요…"
          style={{
            width: "100%", minHeight: "100%",
            background: "transparent",
            border: "none", outline: "none",
            resize: "none",
            color: "var(--color-text-primary)",
            fontFamily: "var(--font-sans)",
            fontSize: 14.5,
            lineHeight: 1.75,
            letterSpacing: "-0.005em",
          }}
        />
      </div>

      {/* Footer */}
      <footer style={{
        padding: "10px 28px",
        borderTop: "1px solid var(--color-border-subtle)",
        background: "var(--color-bg-surface)",
        display: "flex", alignItems: "center", gap: 12,
        fontSize: 11, color: "var(--color-text-muted)",
        flexShrink: 0, whiteSpace: "nowrap",
      }}>
        <span>{wordCount(note.content)} words · {note.content.length} chars</span>
        <div style={{ flex: 1 }} />
        <kbd style={kbdStyle}>⌘S</kbd>
        <span>save</span>
        <kbd style={kbdStyle}>⌘⏎</kbd>
        <span>새 노트</span>
      </footer>
    </section>
  );
};

const kbdStyle = {
  fontFamily: "var(--font-mono)", fontSize: 10,
  padding: "1px 5px",
  background: "var(--color-bg-elevated)",
  border: "1px solid var(--color-border-subtle)",
  borderRadius: "var(--radius-xs)",
  color: "var(--color-text-secondary)",
  fontVariantNumeric: "tabular-nums",
};

const NoteKindChip = ({ kind, interactive }) => (
  <button style={{
    display: "inline-flex", alignItems: "center", gap: 6,
    padding: "4px 10px",
    borderRadius: 999,
    background: `color-mix(in oklab, ${kind.color} 12%, transparent)`,
    color: kind.color,
    border: "none",
    fontSize: 11.5, fontWeight: 700,
    cursor: interactive ? "pointer" : "default",
    whiteSpace: "nowrap", flexShrink: 0,
  }}>
    <Icon name={kind.icon} size={11} color={kind.color} />
    {kind.label} · {kind.ko}
    {interactive ? <Icon name="chevron-down" size={10} color={kind.color} /> : null}
  </button>
);

const MetaChip = ({ icon, label, link, accent }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 5,
    padding: "3px 8px",
    borderRadius: "var(--radius-xs)",
    background: accent ? "var(--color-accent-subtle)" : "var(--color-bg-panel)",
    color: accent ? "var(--color-accent)" : "var(--color-text-muted)",
    fontSize: 11, fontWeight: 500,
    cursor: link ? "pointer" : "default",
    maxWidth: 280, flexShrink: 0,
  }}>
    <Icon name={icon} size={10} color={accent ? "var(--color-accent)" : "var(--color-text-muted)"} />
    <span style={{ overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{label}</span>
    {link ? <Icon name="external-link" size={9} color="var(--color-text-muted)" /> : null}
  </span>
);

const SaveStatus = () => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 5,
    fontSize: 11, color: "var(--color-text-muted)",
    whiteSpace: "nowrap", flexShrink: 0,
  }}>
    <Icon name="check" size={11} color="var(--color-success)" />
    저장됨
  </span>
);

const IconButtonNotes = ({ name, active, title, danger }) => {
  const [hover, setHover] = React.useState(false);
  return (
    <button
      title={title}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{
        width: 28, height: 28,
        background: active
          ? "var(--color-accent-subtle)"
          : hover ? "var(--color-bg-hover)" : "transparent",
        color: active
          ? "var(--color-accent)"
          : danger && hover ? "var(--color-danger)"
          : hover ? "var(--color-text-secondary)"
          : "var(--color-text-muted)",
        border: "none",
        borderRadius: "var(--radius-sm)",
        cursor: "pointer",
        display: "flex", alignItems: "center", justifyContent: "center",
        transition: "background var(--transition-fast), color var(--transition-fast)",
      }}
    >
      <Icon name={name} size={14} />
    </button>
  );
};

const EmptyEditor = () => (
  <section style={{
    flex: 1,
    display: "flex", flexDirection: "column",
    alignItems: "center", justifyContent: "center",
    color: "var(--color-text-muted)", gap: 8,
  }}>
    <Icon name="sticky-note" size={32} color="var(--color-text-muted)" style={{ opacity: 0.35 }} />
    <div style={{ fontSize: 13 }}>노트를 선택하면 여기서 편집할 수 있습니다.</div>
  </section>
);

const wordCount = (text) => text.trim().split(/\s+/).filter(Boolean).length;

window.NotesView = NotesView;
