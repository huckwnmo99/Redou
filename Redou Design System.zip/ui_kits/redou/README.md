# Redou UI kit

A pixel-faithful interactive recreation of the Redou desktop app. Open `index.html` to use the prototype.

## What's in here

- `index.html` — entry point. Mounts the full app shell.
- `styles.css` — re-exports `../../colors_and_type.css` plus a few app-shell-only rules.
- `Icon.jsx` — tiny wrapper around the Lucide CDN. Use as `<Icon name="library" size={15} />`.
- `data.jsx` — mock papers and folders that drive the prototype. Realistic-sounding research papers in catalysis, RAG, and OCR — match Redou's actual domain.
- `LeftSidebar.jsx` — fixed 224 px nav with brand lockup, workspace tabs, folder tree, settings footer.
- `TopBar.jsx` — breadcrumb, search field, sort, view-mode toggle, primary Add-paper button, inspector toggle. Exports `<IconButton>`.
- `LibraryView.jsx` — papers grid and list. Inlines `<PaperCard>`, `<PaperListItem>`, `<Tag>`, `<StatusBadge>`, `<ProcessingBadge>`.
- `PaperDetailView.jsx` — paper detail with **Overview / Reader / Notes / Figures / Highlights** tabs. The Reader pane shows a fake PDF page with two highlight colors and an extracted figure caption box.
- `ChatView.jsx` — **the marquee feature**. Table-vs-Q&A mode toggle, user bubble, table report with `[1]`-style citations into a references block, Guardian-verified badge, and a fake pipeline progress strip when you send a new message.
- `AppShell.jsx` — wires everything together: routing between Library / Detail / Chat, the auto-cycling job toast (running → complete → null → ...), the bottom-docked right inspector.

## What works (click-thru)

- Click a paper card to select it (double-stroke selected state).
- Double-click or hit `Open detail` to drill into the paper.
- "Back to Library" returns you.
- Grid/list view toggle in the top bar.
- Sort menu (year / title / citations / added).
- Live search field — filters by title / authors / tags.
- Star toggle on each card or list row.
- Inspector toggle (bottom dock).
- Folder filtering (Starred / Recent).
- Switch to Chat — type a query and hit Enter to watch the 4-stage pipeline animate (Intent → Retrieval → Table → Guardian), then a verified comparison table renders.
- Chat mode toggle (Table vs Q&A).
- "Add Paper" pushes a running job toast.

## What's faked

- No real auth — the AuthView lives in the codebase, not this kit.
- The Reader pane shows a stylised PDF rather than a real `pdfjs-dist` render.
- Figures pane shows generated SVG-ish placeholders, not real extracted images.
- Settings / Processing / Notes top-level views are placeholders pointing at the real implementation paths in the codebase.

## How to use these in another project

Lift any component file as-is — they are self-contained and only depend on `Icon`, the design tokens in `colors_and_type.css`, and (where noted) the badge constants. To use outside this kit:

1. Copy `colors_and_type.css` + `assets/Redou.png` into your project.
2. Copy `Icon.jsx` and load Lucide via CDN (`https://unpkg.com/lucide@latest`).
3. Copy the component file you need and import it after React + Babel.

For production-quality work, prefer the **real components in the upstream repo** at `frontend/src/components/` and `frontend/src/features/` — they have full keyboard, drag-drop, and IPC behaviour that this kit only mimics visually.

## Match to the upstream code

| File in this kit | Real implementation |
| ---------------- | ------------------- |
| `AppShell.jsx`        | `frontend/src/app/AppShell.tsx` |
| `LeftSidebar.jsx`     | `frontend/src/app/LeftSidebar.tsx` |
| `TopBar.jsx`          | `frontend/src/app/TopBar.tsx` |
| `LibraryView.jsx`     | `frontend/src/features/library/{LibraryView,PaperCard,PaperListItem}.tsx` |
| `PaperDetailView.jsx` | `frontend/src/features/paper/{PaperDetailView,PdfReaderWorkspace}.tsx` |
| `ChatView.jsx`        | `frontend/src/features/chat/{ChatView,ChatMessageList,ChatTableReport,ChatPipelineStatus,ChatInput}.tsx` |
| Badges, Tag, IconButton | `frontend/src/components/{StatusBadge,ProcessingBadge,Tag,IconButton}.tsx` |
