// PaperDetailView — fake PDF reader workspace: left column = page thumbnails,
// center = the "PDF page" with highlights, right = inspector / notes.
const PaperDetailView = ({ paper }) => {
  const [activeTab, setActiveTab] = React.useState("overview");
  if (!paper) return null;

  const tabs = [
    { id: "overview",  label: "개요",       icon: "file-text" },
    { id: "reader",    label: "Reader",     icon: "book-open" },
    { id: "notes",     label: "노트",       icon: "sticky-note" },
    { id: "figures",   label: "Figures",    icon: "images" },
    { id: "highlights", label: "하이라이트", icon: "highlighter" },
  ];

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column", background: "var(--color-bg-surface)" }}>
      {/* paper header */}
      <div style={{
        padding: "18px 24px 14px",
        borderBottom: "1px solid var(--color-border-subtle)",
        display: "grid", gap: 10,
      }}>
        <div style={{ display: "flex", alignItems: "flex-start", gap: 14 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{
              fontSize: 11, fontWeight: 700, letterSpacing: "0.08em", textTransform: "uppercase",
              color: "var(--color-text-muted)", marginBottom: 6,
            }}>{paper.venue} · {paper.year}</div>
            <h1 style={{ fontSize: 22, lineHeight: 1.25, color: "var(--color-text-primary)" }}>
              {paper.title}
            </h1>
            <div style={{ fontSize: 13, color: "var(--color-text-secondary)", marginTop: 6 }}>
              {paper.authors.map((a) => a.name).join(", ")}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
            <ProcessingBadge status={paper.processingStatus} />
            <StatusBadge status={paper.status} />
          </div>
        </div>

        <div style={{ display: "flex", gap: 12, alignItems: "center" }}>
          <StatItemLarge icon="quote" label="Citations" value={paper.citationCount.toLocaleString()} />
          <StatItemLarge icon="file-text" label="Figures" value={paper.figureCount} />
          <StatItemLarge icon="sticky-note" label="Notes" value={paper.noteCount} />
          <StatItemLarge icon="hash" label="Chunks" value="142" />
          <div style={{ flex: 1 }} />
          <div style={{ display: "flex", gap: 4 }}>
            {paper.tags.map((t) => <Tag key={t} label={t} />)}
          </div>
        </div>

        <div style={{
          display: "flex", gap: 2,
          borderBottom: "1px solid var(--color-border-subtle)",
          marginTop: 4, marginBottom: -14,
        }}>
          {tabs.map((tab) => {
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                style={{
                  display: "inline-flex", alignItems: "center", gap: 6,
                  padding: "10px 14px",
                  border: "none", background: "transparent",
                  borderBottom: active ? "2px solid var(--color-accent)" : "2px solid transparent",
                  color: active ? "var(--color-accent)" : "var(--color-text-secondary)",
                  fontSize: 12.5, fontWeight: active ? 600 : 500, cursor: "pointer",
                  marginBottom: -1,
                }}
              >
                <Icon name={tab.icon} size={13} />
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* content */}
      <div style={{ flex: 1, overflow: "hidden", display: "flex" }}>
        {activeTab === "overview" ? <OverviewPane paper={paper} /> : null}
        {activeTab === "reader" ? <ReaderPane paper={paper} /> : null}
        {activeTab === "notes" ? <NotesPane /> : null}
        {activeTab === "figures" ? <FiguresPane /> : null}
        {activeTab === "highlights" ? <HighlightsPane /> : null}
      </div>
    </div>
  );
};

const StatItemLarge = ({ icon, label, value }) => (
  <div style={{
    display: "flex", alignItems: "center", gap: 6,
    padding: "6px 10px",
    background: "var(--color-bg-elevated)",
    border: "1px solid var(--color-border-subtle)",
    borderRadius: "var(--radius-sm)",
  }}>
    <Icon name={icon} size={12} color="var(--color-text-muted)" />
    <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>{label}</span>
    <span style={{
      fontSize: 12, fontWeight: 700, color: "var(--color-text-primary)",
      fontVariantNumeric: "tabular-nums",
    }}>{value}</span>
  </div>
);

const OverviewPane = ({ paper }) => (
  <div className="scroll-y" style={{ flex: 1, padding: "20px 24px" }}>
    <div style={{ display: "grid", gap: 24, maxWidth: 760 }}>
      <section>
        <div className="eyebrow" style={{ marginBottom: 6 }}>Abstract · 초록</div>
        <p style={{ fontSize: 14, lineHeight: 1.75, color: "var(--color-text-primary)" }}>
          {paper.abstract}
        </p>
      </section>
      <section>
        <div className="eyebrow" style={{ marginBottom: 8 }}>Key chunks · 핵심 청크</div>
        <div style={{ display: "grid", gap: 8 }}>
          {["Methods", "Results", "Discussion"].map((sec, i) => (
            <div key={sec} style={{
              background: "var(--color-bg-elevated)",
              border: "1px solid var(--color-border-subtle)",
              borderRadius: "var(--radius-md)",
              padding: "12px 14px",
            }}>
              <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 4 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: "var(--color-accent)" }}>§ {sec}</span>
                <span style={{ fontSize: 10.5, color: "var(--color-text-muted)" }}>p. {3 + i * 2}</span>
              </div>
              <p style={{ fontSize: 12.5, lineHeight: 1.65, color: "var(--color-text-secondary)" }}>
                Continuous-flow reactor packed with H-ZSM-5 (Si/Al = 23) under <span className="eq">$T = 320\,^\circ\text{C}$</span> showed an intrinsic rate constant of <span className="eq">$k_\text{cat} = 4.2 \times 10^{"{-3}"} \,\text{s}^{"{-1}"}$</span>, with negligible diffusion limitation up to particle sizes of 250 µm.
              </p>
            </div>
          ))}
        </div>
      </section>
    </div>
  </div>
);

const ReaderPane = () => (
  <>
    {/* page thumbnails */}
    <aside style={{
      width: 132, background: "var(--color-bg-panel)",
      borderRight: "1px solid var(--color-border-subtle)",
      padding: 10, display: "grid", gap: 8, alignContent: "start",
      overflow: "auto",
    }}>
      {[1, 2, 3, 4, 5, 6].map((n) => (
        <div key={n} style={{
          aspectRatio: "0.77",
          background: "var(--color-bg-elevated)",
          border: n === 2 ? "2px solid var(--color-accent)" : "1px solid var(--color-border-subtle)",
          borderRadius: "var(--radius-sm)",
          padding: 6,
          display: "flex", flexDirection: "column", justifyContent: "space-between",
        }}>
          <div style={{ display: "grid", gap: 2 }}>
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} style={{
                height: 2.5, background: "var(--color-border-subtle)",
                width: `${50 + (i * 7) % 50}%`,
              }} />
            ))}
          </div>
          <span style={{ fontSize: 9, color: "var(--color-text-muted)", textAlign: "center" }}>{n}</span>
        </div>
      ))}
    </aside>

    {/* fake PDF */}
    <div className="scroll-y" style={{ flex: 1, padding: "20px 24px", background: "#e9eef5" }}>
      <div style={{
        maxWidth: 640, margin: "0 auto",
        background: "#fff",
        border: "1px solid var(--color-border-subtle)",
        borderRadius: "var(--radius-sm)",
        padding: "44px 56px",
        boxShadow: "var(--shadow-sm)",
        fontFamily: "Georgia, 'Times New Roman', serif",
        fontSize: 11.5, lineHeight: 1.7, color: "#1a2233",
      }}>
        <h2 style={{ fontFamily: "var(--font-sans)", fontSize: 15, marginBottom: 12, fontWeight: 700 }}>
          2. Continuous-flow apparatus
        </h2>
        <p style={{ marginBottom: 10 }}>
          The reactor consisted of a 4 mm OD stainless-steel tube packed with{" "}
          <mark style={{
            background: "rgba(245,158,11,0.32)", padding: "1px 2px",
            borderRadius: 2, color: "inherit",
          }}>1.20 g of pelletised H-ZSM-5</mark> (Si/Al = 23, supplied by Zeolyst).
          The bed was sandwiched between two plugs of quartz wool and operated
          at atmospheric pressure with helium as the carrier gas.
        </p>
        <p style={{ marginBottom: 10 }}>
          Mass transfer artefacts were ruled out by varying the catalyst particle
          size from 80 to 250 µm at constant W/F (Mears criterion ≤ 0.05). The
          residence-time distribution was measured by a step input of argon and
          fitted to a single-CSTR model with{" "}
          <mark style={{
            background: "rgba(37,99,235,0.22)", padding: "1px 2px", borderRadius: 2,
          }}>τ = 1.8 ± 0.2 s</mark>.
        </p>
        <h2 style={{ fontFamily: "var(--font-sans)", fontSize: 15, margin: "16px 0 12px", fontWeight: 700 }}>
          3. Intrinsic kinetics
        </h2>
        <p style={{ marginBottom: 10 }}>
          The intrinsic alkylation rate constant{" "}
          <span style={{ fontFamily: "var(--font-mono)", background: "rgba(15,23,42,0.04)", padding: "1px 4px", borderRadius: 3 }}>
            k_cat = 4.2 × 10⁻³ s⁻¹
          </span>{" "}
          was obtained at 320 °C with an apparent activation energy of 78 kJ mol⁻¹
          over the range 290–340 °C.
        </p>
        <div style={{
          margin: "16px 0", padding: "10px 14px",
          border: "1px dashed var(--color-border)",
          borderRadius: 4, fontSize: 10.5, color: "var(--color-text-muted)",
          fontFamily: "var(--font-sans)",
        }}>
          Figure 2 — Arrhenius plot for benzene alkylation over H-ZSM-5 in the
          continuous-flow apparatus (extracted by pdf-heuristics).
        </div>
      </div>
    </div>
  </>
);

const NotesPane = () => (
  <div className="scroll-y" style={{ flex: 1, padding: "20px 24px" }}>
    <div style={{ display: "grid", gap: 12, maxWidth: 720 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <h2 style={{ fontSize: 18, fontWeight: 600 }}>노트 · Notes</h2>
        <div style={{ flex: 1 }} />
        <button style={{
          display: "inline-flex", alignItems: "center", gap: 6,
          padding: "0 12px", height: 30,
          borderRadius: "var(--radius-sm)", border: "none",
          background: "var(--color-accent)", color: "#fff",
          fontSize: 12, fontWeight: 500, cursor: "pointer",
        }}>
          <Icon name="plus" size={13} />New note
        </button>
      </div>
      {[
        { title: "Reaction conditions vs Park 2022", body: "다른 zeolite ratio에서 비교 필요. 320 °C가 sweet spot으로 보임.", page: 3, time: "2h" },
        { title: "Open question — coking onset", body: "Figure 2 위 350 °C에서 deactivation slope이 갑자기 바뀜. mechanism 가설?", page: 5, time: "1d" },
        { title: "Method follow-up", body: "Mears criterion 계산 다시 확인. particle size 250 µm 위는 측정 안 됨.", page: 4, time: "3d" },
      ].map((n) => (
        <article key={n.title} style={{
          background: "var(--color-bg-elevated)",
          border: "1px solid var(--color-border-subtle)",
          borderRadius: "var(--radius-md)",
          padding: "14px 16px",
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
            <strong style={{ fontSize: 13, color: "var(--color-text-primary)" }}>{n.title}</strong>
            <div style={{ flex: 1 }} />
            <span style={{
              fontSize: 10.5, color: "var(--color-accent)",
              background: "var(--color-accent-subtle)",
              padding: "2px 6px", borderRadius: "var(--radius-xs)",
            }}>p. {n.page}</span>
            <span style={{ fontSize: 10.5, color: "var(--color-text-muted)" }}>{n.time}</span>
          </div>
          <p style={{ fontSize: 12.5, color: "var(--color-text-secondary)", lineHeight: 1.7 }}>{n.body}</p>
        </article>
      ))}
    </div>
  </div>
);

const FiguresPane = () => (
  <div className="scroll-y" style={{ flex: 1, padding: "20px 24px" }}>
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))",
      gap: 12,
    }}>
      {[
        { type: "figure", n: 1, caption: "Schematic of the continuous-flow reactor." },
        { type: "table",  n: 1, caption: "Mears and Weisz–Prater criteria for the experimental window." },
        { type: "figure", n: 2, caption: "Arrhenius plot over 290–340 °C." },
        { type: "equation", n: 1, caption: "$r = k_\\text{cat}\\,C_\\text{B}$" },
        { type: "figure", n: 3, caption: "Coke deposition vs time-on-stream." },
        { type: "table",  n: 2, caption: "Comparison with literature kinetic parameters." },
      ].map((f, i) => (
        <div key={i} style={{
          background: "var(--color-bg-elevated)",
          border: "1px solid var(--color-border-subtle)",
          borderRadius: "var(--radius-md)",
          overflow: "hidden",
          display: "grid", gridTemplateRows: "140px auto",
        }}>
          <div style={{
            background: f.type === "table" ? "#fff" : f.type === "equation" ? "var(--color-bg-panel)" : "#e9eef5",
            display: "flex", alignItems: "center", justifyContent: "center",
            color: "var(--color-text-muted)",
            fontFamily: f.type === "equation" ? "var(--font-mono)" : "var(--font-sans)",
            fontSize: f.type === "equation" ? 18 : 12,
            position: "relative",
          }}>
            {f.type === "table" ? (
              <div style={{ width: "80%" }}>
                {[0, 1, 2, 3].map((r) => (
                  <div key={r} style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", borderBottom: "1px solid var(--color-border-subtle)" }}>
                    {[0, 1, 2].map((c) => (
                      <div key={c} style={{ padding: "4px 6px", fontSize: 9, color: r === 0 ? "var(--color-text-primary)" : "var(--color-text-secondary)", fontWeight: r === 0 ? 700 : 400 }}>
                        {r === 0 ? ["Particle", "Mears", "W-P"][c] : `${80 + r * 60}` + ["µm", "", ""][c] || "✓"}
                      </div>
                    ))}
                  </div>
                ))}
              </div>
            ) : f.type === "equation" ? (
              <span>{f.caption}</span>
            ) : (
              <Icon name="image" size={28} color="var(--color-text-muted)" />
            )}
          </div>
          <div style={{ padding: "10px 12px" }}>
            <div style={{ fontSize: 10.5, color: "var(--color-accent)", fontWeight: 700, marginBottom: 3 }}>
              {f.type === "table" ? "Table" : f.type === "equation" ? "Equation" : "Figure"} {f.n}
            </div>
            <div style={{ fontSize: 11.5, color: "var(--color-text-secondary)", lineHeight: 1.55 }}>
              {f.type === "equation" ? "Intrinsic alkylation rate." : f.caption}
            </div>
          </div>
        </div>
      ))}
    </div>
  </div>
);

const HighlightsPane = () => (
  <div className="scroll-y" style={{ flex: 1, padding: "20px 24px" }}>
    <div style={{ display: "grid", gap: 10, maxWidth: 720 }}>
      {[
        { color: "rgba(245,158,11,0.5)", text: "1.20 g of pelletised H-ZSM-5", note: "Methods", page: 3 },
        { color: "rgba(37,99,235,0.4)",  text: "τ = 1.8 ± 0.2 s", note: "RTD parameter", page: 3 },
        { color: "rgba(15,118,110,0.4)", text: "k_cat = 4.2 × 10⁻³ s⁻¹ at 320 °C", note: "Core result", page: 5 },
        { color: "rgba(220,38,38,0.4)",  text: "deactivation slope changes above 350 °C", note: "Open question", page: 5 },
      ].map((h, i) => (
        <div key={i} style={{
          background: "var(--color-bg-elevated)",
          border: "1px solid var(--color-border-subtle)",
          borderRadius: "var(--radius-md)",
          padding: "12px 14px",
          display: "grid", gap: 6,
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <span style={{ width: 6, height: 18, borderRadius: 2, background: h.color }} />
            <span style={{ fontSize: 13, color: "var(--color-text-primary)" }}>{h.text}</span>
            <div style={{ flex: 1 }} />
            <span style={{
              fontSize: 10.5, color: "var(--color-accent)",
              background: "var(--color-accent-subtle)",
              padding: "2px 6px", borderRadius: "var(--radius-xs)",
            }}>p. {h.page}</span>
          </div>
          <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>— {h.note}</span>
        </div>
      ))}
    </div>
  </div>
);

window.PaperDetailView = PaperDetailView;
