// AppShell — full Redou window: outer translucent shell, sidebar, top bar,
// main content (Library / PaperDetail / Chat / etc.), and the bottom-right job toast.

const AppShell = () => {
  const [activeNav, setActiveNav] = React.useState("library");
  const [activeFolderId, setActiveFolderId] = React.useState(null);
  const [selectedPaperId, setSelectedPaperId] = React.useState(null);
  const [paperDetailOpen, setPaperDetailOpen] = React.useState(false);
  const [searchQuery, setSearchQuery] = React.useState("");
  const [sortKey, setSortKey] = React.useState("addedAt");
  const [viewMode, setViewMode] = React.useState("grid");
  const [inspectorOpen, setInspectorOpen] = React.useState(false);
  const [addPaperOpen, setAddPaperOpen] = React.useState(false);
  const [papers, setPapers] = React.useState(MOCK_PAPERS);
  const [toast, setToast] = React.useState({
    kind: "running",
    title: "Extracting paper",
    description: "attention-is-all-you-need.pdf · GLM-OCR 표 추출 중",
    progress: 62,
  });

  // Auto-cycle the toast through running → completed → null → running
  React.useEffect(() => {
    if (!toast) {
      const t = setTimeout(() => setToast({
        kind: "running",
        title: "Extracting paper",
        description: "rag-table-generation.pdf · GROBID 메타데이터 추출 중",
        progress: 22,
      }), 6000);
      return () => clearTimeout(t);
    }
    if (toast.kind === "running") {
      const t = setTimeout(() => setToast({
        kind: "completed",
        title: "Import complete",
        description: "3 papers · 18 figures · 7 equations indexed.",
        progress: 100,
      }), 4000);
      return () => clearTimeout(t);
    }
    if (toast.kind === "completed") {
      const t = setTimeout(() => setToast(null), 4000);
      return () => clearTimeout(t);
    }
  }, [toast]);

  const openPaper = (id) => {
    setSelectedPaperId(id);
    setPaperDetailOpen(true);
    setActiveNav("library");
  };
  const closePaperDetail = () => {
    setPaperDetailOpen(false);
  };

  const filteredPapers = React.useMemo(() => {
    if (!activeFolderId) return papers;
    if (activeFolderId === "starred") return papers.filter((p) => p.starred);
    if (activeFolderId === "recent")  return papers.slice(0, 4);
    return papers; // folder mapping not modelled — show all
  }, [papers, activeFolderId]);

  const toggleStar = (id) => {
    setPapers((prev) => prev.map((p) => p.id === id ? { ...p, starred: !p.starred } : p));
  };

  const selectedPaper = papers.find((p) => p.id === selectedPaperId);

  // breadcrumb
  let breadcrumb = "라이브러리";
  if (activeNav === "library") {
    if (paperDetailOpen && selectedPaper) breadcrumb = selectedPaper.title;
    else if (!activeFolderId)             breadcrumb = "전체 논문";
    else if (activeFolderId === "starred") breadcrumb = "Starred";
    else if (activeFolderId === "recent")  breadcrumb = "Recent";
    else breadcrumb = MOCK_FOLDERS.find((f) => f.id === activeFolderId)?.name || "Library";
  } else if (activeNav === "chat")       breadcrumb = "Chat · 채팅";
  else if (activeNav === "search")       breadcrumb = "Search · 검색";
  else if (activeNav === "figures")      breadcrumb = "Figures";
  else if (activeNav === "notes")        breadcrumb = "Notes · 노트";
  else if (activeNav === "processing")   breadcrumb = "Processing · 처리";
  else if (activeNav === "settings")     breadcrumb = "Settings · 설정";

  const showLibraryControls = activeNav === "library" && !paperDetailOpen;
  const showBack = activeNav === "library" && paperDetailOpen;

  // toast tone palette
  const jobTone = !toast ? null
    : toast.kind === "failed"
      ? { border: "rgba(220, 38, 38, 0.22)", background: "rgba(254, 242, 242, 0.96)", accent: "#dc2626" }
    : toast.kind === "completed"
      ? { border: "rgba(15, 118, 110, 0.22)", background: "rgba(240, 253, 250, 0.96)", accent: "#0f766e" }
    : { border: "rgba(37, 99, 235, 0.22)",  background: "rgba(239, 246, 255, 0.96)", accent: "#2563eb" };

  return (
    <div style={{
      display: "flex", width: "100vw", height: "100vh",
      background: "rgba(255,255,255,0.2)",
      overflow: "hidden", padding: 10, gap: 10, position: "relative",
    }}>
      <div style={{
        display: "flex", width: "100%", height: "100%", overflow: "hidden",
        border: "1px solid var(--color-border-subtle)",
        borderRadius: "var(--radius-xl)",
        background: "rgba(248,250,252,0.82)",
        boxShadow: "var(--shadow-md)",
        backdropFilter: "blur(16px)",
      }}>
        <LeftSidebar
          activeNav={activeNav}
          setActiveNav={(v) => {
            setActiveNav(v);
            if (v !== "library") setPaperDetailOpen(false);
          }}
          activeFolderId={activeFolderId}
          setActiveFolderId={setActiveFolderId}
        />

        <div style={{
          flex: 1, display: "flex", flexDirection: "column",
          minWidth: 0, overflow: "hidden",
        }}>
          <TopBar
            breadcrumb={breadcrumb}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            sortKey={sortKey}
            setSortKey={setSortKey}
            viewMode={viewMode}
            setViewMode={setViewMode}
            inspectorOpen={inspectorOpen}
            toggleInspector={() => setInspectorOpen((v) => !v)}
            showLibraryControls={showLibraryControls}
            showBack={showBack}
            onBack={closePaperDetail}
            hideSearch={activeNav === "search"}
            onAddPaper={() => setAddPaperOpen(true)}
          />

          <div style={{ flex: 1, position: "relative", overflow: "hidden", background: "var(--color-bg-surface)" }}>
            <div style={{ width: "100%", height: "100%", overflow: "hidden" }}>
              {activeNav === "library" && !paperDetailOpen ? (
                <LibraryView
                  papers={filteredPapers}
                  selectedPaperId={selectedPaperId}
                  setSelectedPaperId={setSelectedPaperId}
                  openPaper={openPaper}
                  viewMode={viewMode}
                  searchQuery={searchQuery}
                  sortKey={sortKey}
                  onToggleStar={toggleStar}
                />
              ) : null}
              {activeNav === "library" && paperDetailOpen ? (
                <PaperDetailView paper={selectedPaper} />
              ) : null}
              {activeNav === "chat" ? <ChatView /> : null}
              {activeNav === "settings" ? <SettingsView /> : null}
              {activeNav === "search" ? <SearchView /> : null}
              {activeNav === "notes" ? <NotesView /> : null}
              {activeNav !== "library" && activeNav !== "chat" && activeNav !== "settings" && activeNav !== "search" && activeNav !== "notes" ? <Placeholder name={activeNav} /> : null}
            </div>

            {inspectorOpen ? (
              <RightInspector paper={selectedPaper} onClose={() => setInspectorOpen(false)} />
            ) : null}
          </div>
        </div>
      </div>

      {toast ? (
        <div
          onClick={() => setActiveNav("processing")}
          style={{
            position: "absolute", right: 26, bottom: 24,
            width: 320, padding: "13px 14px",
            borderRadius: "var(--radius-lg)",
            border: `1px solid ${jobTone.border}`,
            background: jobTone.background,
            boxShadow: "var(--shadow-md)",
            zIndex: 40, cursor: "pointer",
          }}
        >
          <div style={{
            display: "flex", alignItems: "center", justifyContent: "space-between",
            gap: 10, marginBottom: 6,
          }}>
            <div style={{ fontSize: 12.5, fontWeight: 700, color: jobTone.accent }}>{toast.title}</div>
            {toast.progress !== undefined ? (
              <div style={{
                fontSize: 11.5, fontWeight: 700, color: jobTone.accent,
                fontVariantNumeric: "tabular-nums",
              }}>{toast.progress}%</div>
            ) : null}
          </div>
          <div style={{ fontSize: 12.5, lineHeight: 1.65, color: "var(--color-text-secondary)" }}>
            {toast.description}
          </div>
        </div>
      ) : null}

      {addPaperOpen ? (
        <AddPaperModal
          folders={MOCK_FOLDERS}
          onClose={() => setAddPaperOpen(false)}
          onImport={(job) => { setToast(job); setActiveNav("library"); }}
        />
      ) : null}
    </div>
  );
};

const RightInspector = ({ paper, onClose }) => (
  <div style={{
    position: "absolute", left: 0, right: 0, bottom: 0,
    height: "var(--inspector-height)",
    zIndex: 20,
    boxShadow: "0 -4px 24px rgba(15, 23, 42, 0.10)",
    background: "var(--color-bg-elevated)",
    borderTop: "1px solid var(--color-border-subtle)",
  }}>
    <div style={{
      display: "flex", alignItems: "center", gap: 10,
      padding: "10px 16px",
      borderBottom: "1px solid var(--color-border-subtle)",
    }}>
      <Icon name="panel-bottom-open" size={14} color="var(--color-text-muted)" />
      <strong style={{ fontSize: 12.5, color: "var(--color-text-primary)" }}>Inspector</strong>
      <div style={{ flex: 1 }} />
      <button
        onClick={onClose}
        style={{ background: "transparent", border: "none", cursor: "pointer", color: "var(--color-text-muted)" }}
      ><Icon name="x" size={14} /></button>
    </div>
    <div className="scroll-y" style={{ padding: "12px 16px", height: "calc(100% - 41px)" }}>
      {paper ? (
        <div style={{ display: "grid", gap: 12 }}>
          <div>
            <div className="eyebrow">Selected</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: "var(--color-text-primary)", marginTop: 4 }}>
              {paper.title}
            </div>
          </div>
          <div>
            <div className="eyebrow">Abstract</div>
            <p style={{ fontSize: 12.5, lineHeight: 1.65, color: "var(--color-text-secondary)", marginTop: 4 }}>
              {paper.abstract}
            </p>
          </div>
        </div>
      ) : (
        <div style={{ fontSize: 12.5, color: "var(--color-text-muted)" }}>
          논문을 선택하면 인스펙터에 메타데이터가 표시됩니다.
        </div>
      )}
    </div>
  </div>
);

const Placeholder = ({ name }) => (
  <div style={{
    display: "grid", placeItems: "center",
    height: "100%", gap: 10, color: "var(--color-text-muted)",
  }}>
    <Icon name="construction" size={32} color="var(--color-text-muted)" />
    <span style={{ fontSize: 13 }}>{name} 뷰는 UI kit에서 생략되었습니다.</span>
    <span style={{ fontSize: 11.5 }}>Real implementation lives in <code style={{ fontFamily: "var(--font-mono)" }}>frontend/src/features/{name}/</code></span>
  </div>
);

window.AppShell = AppShell;
