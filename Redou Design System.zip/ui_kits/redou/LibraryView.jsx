// Library — papers grid/list. Includes inline PaperCard and PaperListItem.

const formatAuthors = (authors) => {
  if (authors.length === 0) return "Unknown authors";
  if (authors.length === 1) return authors[0].name;
  if (authors.length === 2) return `${authors[0].name} & ${authors[1].name}`;
  return `${authors[0].name} 외`;
};
const formatCitations = (n) => (n >= 1000 ? `${(n / 1000).toFixed(0)}k` : String(n));

const Tag = ({ label }) => (
  <span style={{
    display: "inline-flex", alignItems: "center",
    padding: "2px 7px",
    borderRadius: "var(--radius-xs)",
    background: "var(--color-tag-bg)",
    color: "var(--color-text-muted)",
    fontSize: 10, fontWeight: 500,
    letterSpacing: "0.02em", whiteSpace: "nowrap",
    border: "1px solid var(--color-border-subtle)",
  }}>{label}</span>
);
window.Tag = Tag;

const STATUS_CFG = {
  unread:  { label: "Unread",  color: "#4e5672", bg: "rgba(78,86,114,0.15)" },
  reading: { label: "Reading", color: "#f59e0b", bg: "rgba(245,158,11,0.12)" },
  read:    { label: "Read",    color: "#22d3a0", bg: "rgba(34,211,160,0.12)" },
};
const StatusBadge = ({ status }) => {
  const cfg = STATUS_CFG[status];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "2px 7px", borderRadius: "var(--radius-xs)",
      background: cfg.bg, color: cfg.color,
      fontSize: 10, fontWeight: 600, letterSpacing: "0.03em",
    }}>
      <span style={{ width: 5, height: 5, borderRadius: "50%", background: cfg.color }} />
      {cfg.label}
    </span>
  );
};
window.StatusBadge = StatusBadge;

const PROC_CFG = {
  queued:    { label: "Queued",     color: "#2563eb", bg: "rgba(37,99,235,0.12)" },
  running:   { label: "Extracting", color: "#d97706", bg: "rgba(217,119,6,0.12)" },
  succeeded: { label: "Complete",   color: "#0f766e", bg: "rgba(15,118,110,0.12)" },
  failed:    { label: "Failed",     color: "#dc2626", bg: "rgba(220,38,38,0.12)" },
};
const ProcessingBadge = ({ status }) => {
  const cfg = PROC_CFG[status];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "2px 7px", borderRadius: "var(--radius-xs)",
      background: cfg.bg, color: cfg.color,
      fontSize: 10, fontWeight: 600, letterSpacing: "0.03em",
    }}>
      <span style={{ width: 5, height: 5, borderRadius: "50%", background: cfg.color }} />
      {cfg.label}
    </span>
  );
};
window.ProcessingBadge = ProcessingBadge;

const StatItem = ({ icon, value }) => (
  <div style={{
    display: "flex", alignItems: "center", gap: 4,
    color: "var(--color-text-muted)",
    fontSize: 10.5, fontVariantNumeric: "tabular-nums",
  }}>
    <Icon name={icon} size={10} />
    {value}
  </div>
);

const PaperCard = ({ paper, selected, onSelect, onOpen, onToggleStar }) => (
  <div
    tabIndex={0}
    onClick={onSelect}
    onDoubleClick={onOpen}
    style={{
      background: "var(--color-bg-elevated)",
      border: `1px solid ${selected ? "var(--color-accent)" : "var(--color-border-subtle)"}`,
      borderRadius: "var(--radius-md)",
      padding: "14px 14px 12px",
      cursor: "grab",
      transition: "border-color var(--transition-fast), box-shadow var(--transition-fast)",
      boxShadow: selected ? "0 0 0 1px var(--color-accent)" : "none",
      display: "flex", flexDirection: "column", gap: 10, position: "relative",
    }}
  >
    <div style={{ display: "flex", alignItems: "flex-start", gap: 8 }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 13, fontWeight: 600, color: "var(--color-text-primary)",
          lineHeight: 1.4,
          display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical",
          overflow: "hidden", marginBottom: 4,
        }}>{paper.title}</div>
        <div style={{
          fontSize: 11.5, color: "var(--color-text-muted)",
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
        }}>{formatAuthors(paper.authors)}</div>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 2, flexShrink: 0 }}>
        <button
          onClick={(e) => { e.stopPropagation(); onToggleStar(); }}
          style={{
            background: "transparent", border: "none", cursor: "pointer",
            padding: 2,
            color: paper.starred ? "var(--color-warning)" : "var(--color-text-muted)",
          }}
        >
          <Icon name="star" size={14} style={{ fill: paper.starred ? "var(--color-warning)" : "none" }} />
        </button>
        <button
          onClick={(e) => e.stopPropagation()}
          style={{
            background: "transparent", border: "none", cursor: "pointer",
            padding: 2, color: "var(--color-text-muted)", opacity: 0.5,
          }}
        >
          <Icon name="trash-2" size={13} />
        </button>
      </div>
    </div>

    <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
      <span style={{ fontSize: 11, color: "var(--color-text-muted)", fontWeight: 500 }}>{paper.venue}</span>
      <span style={{ color: "var(--color-border)", fontSize: 10 }}>·</span>
      <span style={{ fontSize: 11, color: "var(--color-text-muted)" }}>{paper.year}</span>
      <div style={{ flex: 1 }} />
      {paper.processingStatus ? <ProcessingBadge status={paper.processingStatus} /> : null}
      <StatusBadge status={paper.status} />
    </div>

    {paper.tags.length > 0 ? (
      <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
        {paper.tags.slice(0, 3).map((t) => <Tag key={t} label={t} />)}
        {paper.tags.length > 3 ? <Tag label={`+${paper.tags.length - 3}`} /> : null}
      </div>
    ) : null}

    <div style={{
      display: "flex", alignItems: "center", gap: 12,
      paddingTop: 6, borderTop: "1px solid var(--color-border-subtle)",
    }}>
      <StatItem icon="quote" value={formatCitations(paper.citationCount)} />
      <StatItem icon="file-text" value={String(paper.figureCount)} />
      <StatItem icon="sticky-note" value={String(paper.noteCount)} />
      <div style={{ flex: 1 }} />
      <button
        onClick={(e) => { e.stopPropagation(); onOpen(); }}
        style={{
          border: "none", background: "transparent",
          color: "var(--color-accent)", fontSize: 11.5, fontWeight: 700, cursor: "pointer",
        }}
      >Open detail</button>
    </div>
  </div>
);

const PaperListItem = ({ paper, selected, onSelect, onOpen, onToggleStar }) => (
  <div
    onClick={onSelect}
    onDoubleClick={onOpen}
    style={{
      display: "flex", alignItems: "center", gap: 12,
      padding: "10px 12px",
      borderRadius: "var(--radius-sm)",
      background: selected ? "var(--color-accent-subtle)" : "transparent",
      border: `1px solid ${selected ? "var(--color-accent)" : "transparent"}`,
      cursor: "grab",
    }}
  >
    <button
      onClick={(e) => { e.stopPropagation(); onToggleStar(); }}
      style={{
        background: "transparent", border: "none", cursor: "pointer",
        color: paper.starred ? "var(--color-warning)" : "var(--color-border)",
        flexShrink: 0, padding: 0,
      }}
    >
      <Icon name="star" size={13} style={{ fill: paper.starred ? "var(--color-warning)" : "none" }} />
    </button>
    <div style={{ flex: 1, minWidth: 0 }}>
      <div style={{
        fontSize: 12.5, fontWeight: 600, color: "var(--color-text-primary)",
        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
      }}>{paper.title}</div>
      <div style={{ fontSize: 11, color: "var(--color-text-muted)", marginTop: 2 }}>
        {formatAuthors(paper.authors)} · {paper.venue} {paper.year}
      </div>
    </div>
    <div style={{ display: "flex", gap: 4, flexShrink: 0 }}>
      {paper.tags.slice(0, 2).map((t) => <Tag key={t} label={t} />)}
    </div>
    {paper.processingStatus ? <ProcessingBadge status={paper.processingStatus} /> : null}
    <div style={{
      display: "flex", alignItems: "center", gap: 4,
      color: "var(--color-text-muted)", fontSize: 11,
      minWidth: 48, flexShrink: 0,
    }}>
      <Icon name="quote" size={10} />
      {formatCitations(paper.citationCount)}
    </div>
    <StatusBadge status={paper.status} />
    <button
      onClick={(e) => { e.stopPropagation(); onOpen(); }}
      style={{
        border: "none", background: "transparent",
        color: "var(--color-accent)", fontSize: 11.5, fontWeight: 700, cursor: "pointer",
      }}
    >Open</button>
  </div>
);

const LibraryView = ({
  papers, selectedPaperId, setSelectedPaperId,
  openPaper, viewMode, searchQuery, sortKey, onToggleStar,
}) => {
  const sorted = React.useMemo(() => {
    const s = [...papers];
    if (sortKey === "year") s.sort((a, b) => b.year - a.year);
    else if (sortKey === "title") s.sort((a, b) => a.title.localeCompare(b.title));
    else if (sortKey === "citations") s.sort((a, b) => b.citationCount - a.citationCount);
    else s.sort((a, b) => b.addedAt.localeCompare(a.addedAt));
    return s;
  }, [papers, sortKey]);

  const filtered = React.useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    if (!q) return sorted;
    return sorted.filter((p) =>
      p.title.toLowerCase().includes(q) ||
      p.authors.some((a) => a.name.toLowerCase().includes(q)) ||
      p.tags.some((t) => t.toLowerCase().includes(q))
    );
  }, [sorted, searchQuery]);

  return (
    <div style={{ height: "100%", display: "flex", flexDirection: "column" }}>
      <div style={{
        padding: "6px 16px",
        fontSize: 11, color: "var(--color-text-muted)",
        borderBottom: "1px solid var(--color-border-subtle)",
        flexShrink: 0,
      }}>
        {searchQuery.trim() ? (
          <>
            <span style={{ color: "var(--color-text-secondary)" }}>“{searchQuery}”</span>에 대한 결과 {filtered.length}개
          </>
        ) : (
          `${filtered.length}개 논문`
        )}
      </div>

      <div className="scroll-y" style={{ flex: 1 }}>
        {viewMode === "list" ? (
          <div style={{ display: "flex", flexDirection: "column", gap: 1, padding: "12px 16px" }}>
            {filtered.map((p) => (
              <PaperListItem
                key={p.id}
                paper={p}
                selected={selectedPaperId === p.id}
                onSelect={() => setSelectedPaperId(selectedPaperId === p.id ? null : p.id)}
                onOpen={() => openPaper(p.id)}
                onToggleStar={() => onToggleStar(p.id)}
              />
            ))}
          </div>
        ) : (
          <div style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
            gap: 10, padding: "12px 16px", alignContent: "start",
          }}>
            {filtered.map((p) => (
              <PaperCard
                key={p.id}
                paper={p}
                selected={selectedPaperId === p.id}
                onSelect={() => setSelectedPaperId(selectedPaperId === p.id ? null : p.id)}
                onOpen={() => openPaper(p.id)}
                onToggleStar={() => onToggleStar(p.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

window.LibraryView = LibraryView;
