// ChatView — Redou's marquee feature: cross-paper comparison-table generation.
// Mode toggle (Table vs Q&A), pipeline status, table report, references.

const PIPELINE_STAGES = [
  { id: "intent",    label: "Intent analysis",  icon: "compass" },
  { id: "retrieval", label: "Retrieval (RAG)",  icon: "search" },
  { id: "table",     label: "Table generation", icon: "table-2" },
  { id: "guardian",  label: "Guardian verify",  icon: "shield-check" },
];

const ChatPipelineStatus = ({ stage }) => (
  <div style={{
    display: "flex", alignItems: "center", gap: 8,
    padding: "10px 14px",
    background: "var(--color-bg-elevated)",
    border: "1px solid var(--color-border-subtle)",
    borderRadius: "var(--radius-md)",
    fontSize: 12, color: "var(--color-text-secondary)",
  }}>
    {PIPELINE_STAGES.map((s, i) => {
      const idx = PIPELINE_STAGES.findIndex((x) => x.id === stage);
      const done = i < idx;
      const active = i === idx;
      return (
        <React.Fragment key={s.id}>
          {i > 0 ? (
            <span style={{
              width: 14, height: 1, background: done || active ? "var(--color-accent)" : "var(--color-border-subtle)",
            }} />
          ) : null}
          <div style={{
            display: "inline-flex", alignItems: "center", gap: 6,
            padding: "4px 8px", borderRadius: "var(--radius-xs)",
            background: active ? "var(--color-accent-subtle)" : "transparent",
            color: active ? "var(--color-accent)" : done ? "var(--color-success)" : "var(--color-text-muted)",
            fontWeight: active ? 600 : 500, fontSize: 11.5,
          }}>
            <Icon name={done ? "check" : s.icon} size={12} />
            {s.label}
          </div>
        </React.Fragment>
      );
    })}
  </div>
);

const TableReport = ({ columns, rows, title }) => (
  <div style={{
    background: "var(--color-bg-elevated)",
    border: "1px solid var(--color-border-subtle)",
    borderRadius: "var(--radius-md)",
    overflow: "hidden",
  }}>
    <div style={{
      padding: "10px 14px",
      borderBottom: "1px solid var(--color-border-subtle)",
      display: "flex", alignItems: "center", gap: 8,
    }}>
      <Icon name="table-2" size={13} color="var(--color-accent)" />
      <strong style={{ fontSize: 12.5, color: "var(--color-text-primary)" }}>{title}</strong>
      <div style={{ flex: 1 }} />
      <span style={{
        display: "inline-flex", alignItems: "center", gap: 4,
        padding: "2px 7px", borderRadius: "var(--radius-xs)",
        background: "rgba(15,118,110,0.12)", color: "var(--color-success)",
        fontSize: 10, fontWeight: 700,
      }}>
        <Icon name="shield-check" size={10} />
        Verified
      </span>
    </div>
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
        <thead>
          <tr>
            {columns.map((c) => (
              <th key={c} style={{
                padding: "8px 12px", textAlign: "left",
                background: "var(--color-bg-surface)",
                borderBottom: "1px solid var(--color-border-subtle)",
                fontSize: 11, fontWeight: 700,
                color: "var(--color-text-secondary)",
              }}>{c}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {row.map((cell, j) => (
                <td key={j} style={{
                  padding: "8px 12px",
                  borderBottom: i === rows.length - 1 ? "none" : "1px solid var(--color-border-subtle)",
                  background: i % 2 ? "var(--color-bg-base)" : "transparent",
                  color: j === 0 ? "var(--color-text-primary)" : "var(--color-text-secondary)",
                  fontWeight: j === 0 ? 600 : 400,
                  fontVariantNumeric: "tabular-nums",
                }}>
                  {cell}
                  {j > 0 && cell !== "—" ? (
                    <sup style={{
                      color: "var(--color-accent)",
                      fontWeight: 600, marginLeft: 3, cursor: "pointer",
                    }}>[{i + 1}]</sup>
                  ) : null}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  </div>
);

const ReferencesBlock = ({ papers }) => (
  <div style={{ display: "grid", gap: 6 }}>
    <div className="eyebrow">References · 참조</div>
    {papers.map((p, i) => (
      <div key={p.id} style={{
        display: "flex", gap: 10, alignItems: "flex-start",
        padding: "8px 10px",
        background: "var(--color-bg-elevated)",
        border: "1px solid var(--color-border-subtle)",
        borderRadius: "var(--radius-sm)",
      }}>
        <span style={{
          flexShrink: 0, fontSize: 11, fontWeight: 700, color: "var(--color-accent)",
          background: "var(--color-accent-subtle)",
          padding: "1px 6px", borderRadius: "var(--radius-xs)",
        }}>[{i + 1}]</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: "var(--color-text-primary)", lineHeight: 1.4 }}>
            {p.title}
          </div>
          <div style={{ fontSize: 11, color: "var(--color-text-muted)", marginTop: 2 }}>
            {p.authors[0]?.name} · {p.venue} {p.year} · p. {3 + i}
          </div>
        </div>
      </div>
    ))}
  </div>
);

const ChatView = ({ openPaper }) => {
  const [conversationType, setConversationType] = React.useState("table");
  const [hasConversation, setHasConversation] = React.useState(true);
  const [pipelineStage, setPipelineStage] = React.useState(null);
  const [input, setInput] = React.useState("");
  const refsList = [MOCK_PAPERS[0], MOCK_PAPERS[5], MOCK_PAPERS[2]];

  const startGeneration = () => {
    if (!input.trim()) return;
    setInput("");
    setPipelineStage("intent");
    setHasConversation(true);
    setTimeout(() => setPipelineStage("retrieval"), 600);
    setTimeout(() => setPipelineStage("table"),     1400);
    setTimeout(() => setPipelineStage("guardian"),  2400);
    setTimeout(() => setPipelineStage(null),        3400);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", overflow: "hidden" }}>
      {/* header */}
      <div style={{
        padding: "14px 20px 10px",
        borderBottom: "1px solid var(--color-border-subtle)",
        display: "flex", flexDirection: "column", gap: 10, flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <span style={{ fontSize: 18, fontWeight: 700, color: "var(--color-text-primary)" }}>
            Research Data Chat · 연구 데이터 채팅
          </span>
          {hasConversation ? (
            <span style={{
              fontSize: 11.5, color: "var(--color-text-muted)",
              background: "var(--color-bg-panel)",
              padding: "2px 8px", borderRadius: "var(--radius-xs)",
            }}>전체 논문 · 6 papers</span>
          ) : null}
        </div>

        <div style={{
          display: "flex", alignItems: "center",
          background: "var(--color-bg-panel)",
          borderRadius: "var(--radius-md)",
          padding: 3, gap: 2, alignSelf: "flex-start",
        }}>
          {[
            { id: "table", icon: "table-2", label: "Table · 테이블" },
            { id: "qa",    icon: "message-circle-question", label: "Q&A" },
          ].map((mode) => {
            const active = conversationType === mode.id;
            return (
              <button
                key={mode.id}
                onClick={() => setConversationType(mode.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "6px 14px", border: "none",
                  borderRadius: "var(--radius-sm)",
                  cursor: "pointer", fontSize: 13,
                  fontWeight: active ? 600 : 400,
                  background: active ? "var(--color-bg-elevated)" : "transparent",
                  color: active ? "var(--color-accent)" : "var(--color-text-muted)",
                  boxShadow: active ? "0 1px 4px rgba(0,0,0,0.10)" : "none",
                  transition: "all var(--transition-fast)",
                  whiteSpace: "nowrap",
                }}
              >
                <Icon name={mode.icon} size={14} />
                {mode.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* messages */}
      <div className="scroll-y" style={{ flex: 1, padding: "20px 0" }}>
        <div style={{ maxWidth: 880, margin: "0 auto", padding: "0 20px", display: "grid", gap: 16 }}>
          {/* user */}
          <div style={{ display: "flex", justifyContent: "flex-end" }}>
            <div className="chat-user-bubble" style={{
              maxWidth: "70%", padding: "10px 14px",
              background: "var(--color-accent)", color: "#fff",
              borderRadius: "var(--radius-lg)",
              fontSize: 13.5, lineHeight: 1.6,
            }}>
              zeolite kinetic 데이터를 비교 테이블로 정리해줘. 활성화 에너지와 반응 속도 상수 중심으로.
            </div>
          </div>

          {/* assistant intro */}
          <div style={{ maxWidth: "85%" }}>
            <div style={{
              display: "flex", alignItems: "center", gap: 8, marginBottom: 8,
            }}>
              <div style={{
                width: 24, height: 24, borderRadius: "var(--radius-sm)",
                background: "linear-gradient(135deg, #2563eb 0%, #0f766e 100%)",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "#fff", fontSize: 11, fontWeight: 700,
              }}>R</div>
              <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--color-text-primary)" }}>Redou Orchestrator</span>
              <span style={{
                fontSize: 10, color: "var(--color-text-muted)",
                background: "var(--color-bg-panel)",
                padding: "1px 6px", borderRadius: "var(--radius-xs)",
              }}>gpt-oss:120b</span>
            </div>

            <p style={{ fontSize: 13.5, lineHeight: 1.7, color: "var(--color-text-primary)", marginBottom: 12 }}>
              세 편의 논문에서 zeolite alkylation kinetics를 비교했습니다. Granite Guardian이 셀별 근거를 확인했고,
              값마다 출처 페이지 번호가 첨자로 붙어 있습니다.
            </p>

            <TableReport
              title="Zeolite alkylation — kinetic comparison"
              columns={["Catalyst", "Si/Al", "T (°C)", "k_cat (s⁻¹)", "Eₐ (kJ/mol)", "Reactor"]}
              rows={[
                ["H-ZSM-5",  "23",  "320", "4.2 × 10⁻³", "78", "Continuous flow"],
                ["H-Beta",   "12.5","300", "1.9 × 10⁻³", "82", "Continuous flow"],
                ["H-MOR",    "20",  "350", "8.6 × 10⁻⁴", "92", "Batch"],
              ]}
            />

            <div style={{ marginTop: 14 }}>
              <ReferencesBlock papers={refsList} />
            </div>
          </div>

          {/* pipeline progress (during streaming) */}
          {pipelineStage ? (
            <div style={{ maxWidth: "85%" }}>
              <ChatPipelineStatus stage={pipelineStage} />
              <div style={{
                fontSize: 11.5, color: "var(--color-text-muted)",
                marginTop: 6, padding: "0 6px",
              }}>
                {pipelineStage === "intent" && "Parsing your request..."}
                {pipelineStage === "retrieval" && "Matching 142 chunks across 6 papers..."}
                {pipelineStage === "table" && "Building comparison matrix..."}
                {pipelineStage === "guardian" && "Granite Guardian checking each cell..."}
              </div>
            </div>
          ) : null}
        </div>
      </div>

      {/* input */}
      <div style={{
        display: "flex", alignItems: "flex-end", gap: 10,
        padding: "16px 20px",
        borderTop: "1px solid var(--color-border-subtle)",
        background: "var(--color-bg-elevated)",
      }}>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.shiftKey) {
              e.preventDefault();
              startGeneration();
            }
          }}
          placeholder={conversationType === "qa"
            ? "논문에 대해 자유롭게 질문하세요..."
            : "필요한 비교 테이블을 설명해주세요..."}
          rows={1}
          style={{
            flex: 1, resize: "none",
            border: "1px solid var(--color-border-subtle)",
            borderRadius: "var(--radius-lg)",
            padding: "14px 18px",
            fontSize: 15, lineHeight: 1.6,
            fontFamily: "var(--font-sans)",
            color: "var(--color-text-primary)",
            background: "var(--color-bg-surface)",
            outline: "none",
            minHeight: 56, maxHeight: 260, overflow: "auto",
          }}
        />
        <button
          onClick={startGeneration}
          disabled={!input.trim()}
          style={{
            width: 48, height: 48,
            borderRadius: "var(--radius-md)",
            border: "none",
            cursor: input.trim() ? "pointer" : "default",
            background: input.trim() ? "var(--color-accent)" : "var(--color-bg-hover)",
            color: input.trim() ? "#fff" : "var(--color-text-muted)",
            display: "flex", alignItems: "center", justifyContent: "center",
            flexShrink: 0,
            opacity: input.trim() ? 1 : 0.5,
          }}
        >
          <Icon name="send" size={18} />
        </button>
      </div>
    </div>
  );
};

window.ChatView = ChatView;
