// AddPaperModal — center dialog for importing papers.
// Primary path: drag-and-drop / pick PDF files. Secondary: import by DOI / arXiv / URL.

const ACCEPTED = ".pdf";

const AddPaperModal = ({ onClose, onImport, folders = [] }) => {
  const [tab, setTab]         = React.useState("upload");   // upload | link
  const [dragOver, setDragOver] = React.useState(false);
  const [files, setFiles]     = React.useState([]);          // [{name,size}]
  const [link, setLink]       = React.useState("");
  const [folderId, setFolderId] = React.useState("none");
  const inputRef = React.useRef(null);

  // close on Escape
  React.useEffect(() => {
    const onKey = (e) => { if (e.key === "Escape") onClose(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const addFiles = (fileList) => {
    const incoming = Array.from(fileList)
      .filter((f) => f.name.toLowerCase().endsWith(".pdf"))
      .map((f) => ({ name: f.name, size: f.size }));
    if (incoming.length) setFiles((prev) => [...prev, ...incoming]);
  };

  const onDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer?.files?.length) addFiles(e.dataTransfer.files);
  };

  const removeFile = (idx) => setFiles((prev) => prev.filter((_, i) => i !== idx));

  const canSubmit = tab === "upload" ? files.length > 0 : link.trim().length > 0;

  const submit = () => {
    if (!canSubmit) return;
    const folderName = folders.find((f) => f.id === folderId)?.name;
    if (tab === "upload") {
      onImport({
        kind: "running",
        title: files.length > 1 ? `Importing ${files.length} PDFs` : "Importing PDF",
        description: `${files[0].name}${files.length > 1 ? ` 외 ${files.length - 1}개` : ""}${folderName ? ` · ${folderName}` : ""} · 추출 파이프라인 시작`,
        progress: 4,
      });
    } else {
      onImport({
        kind: "running",
        title: "Fetching metadata",
        description: `${link.trim().slice(0, 48)}${folderName ? ` · ${folderName}` : ""} · 소스 조회 중`,
        progress: 8,
      });
    }
    onClose();
  };

  return (
    <div
      onMouseDown={onClose}
      style={{
        position: "absolute", inset: 0, zIndex: 60,
        display: "flex", alignItems: "center", justifyContent: "center",
        background: "rgba(15, 23, 42, 0.32)",
        backdropFilter: "blur(3px)",
        padding: 24,
      }}
    >
      <div
        onMouseDown={(e) => e.stopPropagation()}
        style={{
          width: 540, maxWidth: "100%", maxHeight: "100%",
          display: "flex", flexDirection: "column",
          background: "var(--color-bg-elevated)",
          border: "1px solid var(--color-border-subtle)",
          borderRadius: "var(--radius-lg)",
          boxShadow: "var(--shadow-lg)",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <header style={{
          display: "flex", alignItems: "center", gap: 10,
          padding: "16px 20px",
          borderBottom: "1px solid var(--color-border-subtle)",
          flexShrink: 0,
        }}>
          <div style={{
            width: 30, height: 30, borderRadius: "var(--radius-sm)",
            background: "var(--color-accent-subtle)", color: "var(--color-accent)",
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
          }}>
            <Icon name="file-plus" size={16} color="var(--color-accent)" />
          </div>
          <div style={{ minWidth: 0 }}>
            <h2 style={{ fontSize: 15, fontWeight: 600, letterSpacing: "-0.01em" }}>논문 추가</h2>
            <div style={{ fontSize: 11.5, color: "var(--color-text-muted)" }}>Add paper to library</div>
          </div>
          <div style={{ flex: 1 }} />
          <button
            onClick={onClose}
            title="닫기"
            style={{
              width: 30, height: 30, flexShrink: 0,
              background: "transparent", border: "none", cursor: "pointer",
              color: "var(--color-text-muted)", borderRadius: "var(--radius-sm)",
              display: "flex", alignItems: "center", justifyContent: "center",
            }}
          ><Icon name="x" size={16} /></button>
        </header>

        {/* Tabs */}
        <div style={{
          display: "flex", gap: 4, padding: "12px 20px 0", flexShrink: 0,
        }}>
          <TabBtn active={tab === "upload"} onClick={() => setTab("upload")} icon="upload" label="PDF 업로드" />
          <TabBtn active={tab === "link"}   onClick={() => setTab("link")}   icon="link"   label="DOI · arXiv · URL" />
        </div>

        {/* Body */}
        <div className="scroll-y" style={{ padding: "16px 20px", flex: 1, minHeight: 0 }}>
          {tab === "upload" ? (
            <React.Fragment>
              <div
                onClick={() => inputRef.current?.click()}
                onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
                onDragLeave={() => setDragOver(false)}
                onDrop={onDrop}
                style={{
                  display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
                  gap: 10, textAlign: "center",
                  padding: "34px 24px",
                  border: `1.5px dashed ${dragOver ? "var(--color-accent)" : "var(--color-border)"}`,
                  borderRadius: "var(--radius-md)",
                  background: dragOver ? "var(--color-accent-subtle)" : "var(--color-bg-panel)",
                  cursor: "pointer",
                  transition: "background var(--transition-fast), border-color var(--transition-fast)",
                }}
              >
                <div style={{
                  width: 44, height: 44, borderRadius: "50%",
                  background: "var(--color-bg-elevated)",
                  border: "1px solid var(--color-border-subtle)",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: dragOver ? "var(--color-accent)" : "var(--color-text-muted)",
                }}>
                  <Icon name="upload-cloud" size={20} color={dragOver ? "var(--color-accent)" : "var(--color-text-muted)"} />
                </div>
                <div style={{ fontSize: 13.5, fontWeight: 600, color: "var(--color-text-primary)" }}>
                  PDF를 여기로 드래그하거나 클릭해서 선택
                </div>
                <div style={{ fontSize: 11.5, color: "var(--color-text-muted)" }}>
                  여러 개 한 번에 가능 · PDF만 지원
                </div>
                <input
                  ref={inputRef}
                  type="file"
                  accept={ACCEPTED}
                  multiple
                  onChange={(e) => { addFiles(e.target.files); e.target.value = ""; }}
                  style={{ display: "none" }}
                />
              </div>

              {/* Selected files */}
              {files.length > 0 ? (
                <div style={{ display: "grid", gap: 6, marginTop: 12 }}>
                  {files.map((f, i) => (
                    <div key={i} style={{
                      display: "flex", alignItems: "center", gap: 10,
                      padding: "8px 10px",
                      background: "var(--color-bg-panel)",
                      border: "1px solid var(--color-border-subtle)",
                      borderRadius: "var(--radius-sm)",
                    }}>
                      <Icon name="file-text" size={15} color="var(--color-danger)" style={{ flexShrink: 0 }} />
                      <span style={{
                        flex: 1, minWidth: 0, fontSize: 12.5, color: "var(--color-text-primary)",
                        whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis",
                      }}>{f.name}</span>
                      <span style={{ fontSize: 11, color: "var(--color-text-muted)", flexShrink: 0, fontVariantNumeric: "tabular-nums" }}>
                        {fmtSize(f.size)}
                      </span>
                      <button
                        onClick={() => removeFile(i)}
                        title="제거"
                        style={{
                          width: 22, height: 22, flexShrink: 0,
                          background: "transparent", border: "none", cursor: "pointer",
                          color: "var(--color-text-muted)", borderRadius: "var(--radius-xs)",
                          display: "flex", alignItems: "center", justifyContent: "center",
                        }}
                      ><Icon name="x" size={13} /></button>
                    </div>
                  ))}
                </div>
              ) : null}
            </React.Fragment>
          ) : (
            <div style={{ display: "grid", gap: 8 }}>
              <label style={{ fontSize: 12, fontWeight: 600, color: "var(--color-text-secondary)" }}>
                DOI · arXiv ID · 논문 URL
              </label>
              <div style={{
                display: "flex", alignItems: "center", gap: 8,
                padding: "0 12px", height: 40,
                background: "var(--color-bg-panel)",
                border: "1px solid var(--color-border-subtle)",
                borderRadius: "var(--radius-sm)",
              }}>
                <Icon name="link" size={14} color="var(--color-text-muted)" style={{ flexShrink: 0 }} />
                <input
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  placeholder="10.48550/arXiv.1706.03762  ·  arXiv:1706.03762  ·  https://…"
                  autoFocus
                  style={{
                    flex: 1, minWidth: 0, background: "transparent", border: "none", outline: "none",
                    color: "var(--color-text-primary)", fontSize: 12.5,
                  }}
                />
              </div>
              <div style={{ fontSize: 11.5, color: "var(--color-text-muted)", lineHeight: 1.6 }}>
                메타데이터와 PDF를 자동으로 가져옵니다. 가능한 소스: Crossref · arXiv · Semantic Scholar.
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer style={{
          display: "flex", alignItems: "center", gap: 12,
          padding: "14px 20px",
          borderTop: "1px solid var(--color-border-subtle)",
          background: "var(--color-bg-surface)",
          flexShrink: 0,
        }}>
          {/* Folder picker */}
          <div style={{
            display: "flex", alignItems: "center", gap: 7,
            padding: "0 10px", height: 34,
            background: "var(--color-bg-elevated)",
            border: "1px solid var(--color-border-subtle)",
            borderRadius: "var(--radius-sm)",
            minWidth: 0, maxWidth: 220,
          }}>
            <Icon name="folder" size={13} color="var(--color-text-muted)" style={{ flexShrink: 0 }} />
            <select
              value={folderId}
              onChange={(e) => setFolderId(e.target.value)}
              style={{
                flex: 1, minWidth: 0,
                background: "transparent", border: "none", outline: "none",
                color: "var(--color-text-secondary)", fontSize: 12, cursor: "pointer",
                fontFamily: "var(--font-sans)", appearance: "none", paddingRight: 14,
                backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 24 24' fill='none' stroke='%238a96a9' stroke-width='2'%3E%3Cpolyline points='6 9 12 15 18 9'/%3E%3C/svg%3E")`,
                backgroundRepeat: "no-repeat", backgroundPosition: "right center",
              }}
            >
              <option value="none">폴더 없음</option>
              {folders.map((f) => <option key={f.id} value={f.id}>{f.name}</option>)}
            </select>
          </div>

          <div style={{ flex: 1 }} />

          <button
            onClick={onClose}
            style={{
              height: 34, padding: "0 14px",
              background: "transparent",
              border: "1px solid var(--color-border)",
              borderRadius: "var(--radius-sm)",
              color: "var(--color-text-secondary)", fontSize: 12.5, fontWeight: 500,
              cursor: "pointer", whiteSpace: "nowrap",
            }}
          >취소</button>
          <button
            onClick={submit}
            disabled={!canSubmit}
            style={{
              display: "inline-flex", alignItems: "center", gap: 6,
              height: 34, padding: "0 16px",
              background: canSubmit ? "var(--color-accent)" : "var(--color-bg-hover)",
              border: "none", borderRadius: "var(--radius-sm)",
              color: canSubmit ? "#fff" : "var(--color-text-muted)",
              fontSize: 12.5, fontWeight: 600,
              cursor: canSubmit ? "pointer" : "not-allowed",
              whiteSpace: "nowrap",
              transition: "background var(--transition-fast)",
            }}
          >
            <Icon name="plus" size={13} color={canSubmit ? "#fff" : "var(--color-text-muted)"} />
            {tab === "upload"
              ? (files.length > 1 ? `${files.length}개 추가` : "추가")
              : "가져오기"}
          </button>
        </footer>
      </div>
    </div>
  );
};

const TabBtn = ({ active, onClick, icon, label }) => (
  <button
    onClick={onClick}
    style={{
      display: "inline-flex", alignItems: "center", gap: 6,
      padding: "8px 12px",
      background: "transparent", border: "none",
      borderBottom: `2px solid ${active ? "var(--color-accent)" : "transparent"}`,
      color: active ? "var(--color-accent)" : "var(--color-text-muted)",
      fontSize: 12.5, fontWeight: active ? 600 : 500,
      cursor: "pointer", whiteSpace: "nowrap",
      transition: "color var(--transition-fast)",
    }}
  >
    <Icon name={icon} size={14} color={active ? "var(--color-accent)" : "var(--color-text-muted)"} />
    {label}
  </button>
);

const fmtSize = (bytes) => {
  if (!bytes && bytes !== 0) return "";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
};

window.AddPaperModal = AddPaperModal;
