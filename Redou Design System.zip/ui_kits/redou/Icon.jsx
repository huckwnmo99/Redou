// Lucide icon helper. React owns an outer <span>; lucide replaces an inner <i>
// with an <svg>. This way lucide's element-replacement doesn't break React's
// reconciliation (removeChild on a detached node, etc.).
const Icon = ({ name, size = 14, color, style }) => {
  const ref = React.useRef(null);
  React.useEffect(() => {
    if (!ref.current || !window.lucide) return;
    // Reset inner content with a fresh <i data-lucide>, then ask lucide to fill it.
    ref.current.innerHTML = `<i data-lucide="${name}" style="width:${size}px;height:${size}px;${color ? `color:${color};` : ""}display:inline-flex;"></i>`;
    window.lucide.createIcons({ nameAttr: "data-lucide" });
  }, [name, size, color]);
  return (
    <span
      ref={ref}
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        width: size,
        height: size,
        flexShrink: 0,
        color,
        ...style,
      }}
    />
  );
};

window.Icon = Icon;
